const SUBJECT_IMAGES = {
  math: 'assets/images/math.jpg',
  physics: 'assets/images/physics.jpg',
  chem: 'assets/images/chem.jpg',
  bio: 'assets/images/bio.jpg',
  english: 'assets/images/books.jpg',
  history: 'assets/images/education.jpg',
  default: 'assets/images/desk.jpg',
};
const HERO_IMAGE = 'assets/images/hero.jpg';
const DESK_IMAGE = 'assets/images/desk.jpg';
const NOTES_IMAGE = 'assets/images/notes.jpg';
