/* =====================================================
   Personal Study OS — Core Application
   ===================================================== */

(function () {
  'use strict';

  // -------------------- Constants & Helpers --------------------
  const STORAGE_KEY = 'personalStudyOS_v1';
  const DAYS_FA = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه'];
  const MONTHS_FA = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  const MONTHS_EN = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  
  const SUBJECT_IMAGE_FILES = {
    math: 'assets/images/math.jpg',
    physics: 'assets/images/physics.jpg',
    chem: 'assets/images/chem.jpg',
    bio: 'assets/images/bio.jpg',
    english: 'assets/images/books.jpg',
    history: 'assets/images/education.jpg',
    default: 'assets/images/desk.jpg'
  };
  const HERO_IMAGE = 'assets/images/hero.jpg';
  const DESK_IMAGE = 'assets/images/desk.jpg';
  const NOTES_IMAGE = 'assets/images/notes.jpg';

const SUBJECT_COLORS = {
    'ریاضی': 'math', 'فیزیک': 'physics', 'شیمی': 'chem', 'زیست': 'bio',
    'انگلیسی': 'english', 'تاریخ': 'history', 'default': 'default'
  };

  // Subject-themed SVG icons — detailed, educational, premium
  const SUBJECT_ICONS = {
    math: `<svg viewBox="0 0 88 88" fill="none" xmlns="http://www.w3.org/2000/svg">
      <text x="8" y="42" font-family="Georgia,serif" font-size="28" font-weight="600" fill="currentColor" opacity="0.95">π</text>
      <text x="40" y="30" font-family="Georgia,serif" font-size="18" fill="currentColor" opacity="0.65">∑</text>
      <text x="36" y="62" font-family="system-ui,sans-serif" font-size="20" font-weight="700" fill="currentColor" opacity="0.8">x²</text>
      <path d="M10 70 C22 52 34 58 48 48 S70 30 80 38" stroke="currentColor" stroke-width="2.2" fill="none" opacity="0.45" stroke-linecap="round"/>
      <circle cx="70" cy="55" r="9" stroke="currentColor" stroke-width="1.8" opacity="0.4"/>
      <path d="M66 55h8M70 51v8" stroke="currentColor" stroke-width="1.5" opacity="0.5"/>
    </svg>`,
    physics: `<svg viewBox="0 0 88 88" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="44" cy="44" r="7" fill="currentColor" opacity="0.95"/>
      <ellipse cx="44" cy="44" rx="32" ry="12" stroke="currentColor" stroke-width="2" opacity="0.65" transform="rotate(-20 44 44)"/>
      <ellipse cx="44" cy="44" rx="32" ry="12" stroke="currentColor" stroke-width="2" opacity="0.5" transform="rotate(40 44 44)"/>
      <ellipse cx="44" cy="44" rx="32" ry="12" stroke="currentColor" stroke-width="2" opacity="0.4" transform="rotate(100 44 44)"/>
      <circle cx="18" cy="38" r="3" fill="currentColor" opacity="0.7"/>
      <circle cx="68" cy="52" r="2.5" fill="currentColor" opacity="0.55"/>
    </svg>`,
    chem: `<svg viewBox="0 0 88 88" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M32 14h24v10c0 5-3 10-8 15l-4 5 4 6c5 5 8 10 8 15v12H32V65c0-5 3-10 8-15l4-6-4-5c-5-5-8-10-8-15V14z" stroke="currentColor" stroke-width="2.4" fill="currentColor" fill-opacity="0.12"/>
      <path d="M32 14h24" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>
      <path d="M38 8h12" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" opacity="0.6"/>
      <circle cx="40" cy="58" r="4.5" fill="currentColor" opacity="0.55"/>
      <circle cx="52" cy="52" r="3.5" fill="currentColor" opacity="0.4"/>
      <circle cx="46" cy="62" r="2.5" fill="currentColor" opacity="0.35"/>
      <path d="M40 58l6 4M52 52l-6 4" stroke="currentColor" stroke-width="1.4" opacity="0.35"/>
    </svg>`,
    bio: `<svg viewBox="0 0 88 88" fill="none" xmlns="http://www.w3.org/2000/svg">
      <!-- Anatomical-style heart -->
      <path d="M44 72
        C22 56 12 42 16 28
        C19 18 30 14 38 20
        C41 22 43 25 44 28
        C45 25 47 22 50 20
        C58 14 69 18 72 28
        C76 42 66 56 44 72Z" fill="currentColor" opacity="0.88"/>
      <path d="M44 72
        C30 60 20 48 22 36
        C23 30 28 26 34 28" stroke="currentColor" stroke-width="1.5" fill="none" opacity="0.25"/>
      <path d="M38 20 C36 14 32 12 28 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity="0.35"/>
      <path d="M50 20 C52 14 56 12 60 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity="0.35"/>
    </svg>`,
    english: `<svg viewBox="0 0 88 88" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M22 16h36a4 4 0 014 4v50a4 4 0 01-4 4H22a4 4 0 01-4-4V20a4 4 0 014-4z" stroke="currentColor" stroke-width="2.4" fill="currentColor" fill-opacity="0.1"/>
      <path d="M18 20c0-2 2-4 4-4h4v58h-4a4 4 0 01-4-4V20z" fill="currentColor" opacity="0.2"/>
      <path d="M32 32h24M32 42h20M32 52h16" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" opacity="0.65"/>
      <text x="52" y="68" font-family="Georgia,serif" font-size="13" font-weight="700" fill="currentColor" opacity="0.45">Aa</text>
    </svg>`,
    history: `<svg viewBox="0 0 88 88" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M18 68h52" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" opacity="0.7"/>
      <path d="M26 68V32l18-12 18 12v36" stroke="currentColor" stroke-width="2.4" fill="none" opacity="0.75"/>
      <path d="M26 32h36" stroke="currentColor" stroke-width="2" opacity="0.5"/>
      <rect x="34" y="42" width="8" height="14" rx="1" fill="currentColor" opacity="0.4"/>
      <rect x="46" y="42" width="8" height="14" rx="1" fill="currentColor" opacity="0.4"/>
      <path d="M30 26h28" stroke="currentColor" stroke-width="1.8" opacity="0.35"/>
      <circle cx="44" cy="22" r="3" fill="currentColor" opacity="0.5"/>
    </svg>`,
    default: `<svg viewBox="0 0 88 88" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="22" y="14" width="44" height="58" rx="5" stroke="currentColor" stroke-width="2.4" fill="currentColor" fill-opacity="0.1"/>
      <path d="M32 30h24M32 42h20M32 54h16" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" opacity="0.6"/>
    </svg>`
  };

  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function pad(n) { return String(n).padStart(2, '0'); }

  function formatTime(ms) {
    const total = Math.max(0, Math.floor(ms / 1000));
    const m = Math.floor(total / 60);
    const s = total % 60;
    return `${pad(m)}:${pad(s)}`;
  }

  function formatDuration(mins) {
    if (mins < 60) return `${mins} دقیقه`;
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return m ? `${h}س ${m}د` : `${h} ساعت`;
  }

  // -------------------- State --------------------
  let state = {
    user: { name: '', onboarded: false },
    settings: {
      theme: 'neon',
      calendarType: 'jalali',
      weekStart: 6, // Saturday
      timeFormat: '24',
      soundEnabled: true,
      soundVolume: 0.5,
      animationIntensity: 'normal',
      notifications: true,
      aiProvider: 'groq',
      aiApiKey: '',
      aiModel: 'llama-3.3-70b-versatile',
      aiBaseUrl: ''
    },
    school: {
      days: [6, 0, 1, 2, 3], // Sat-Wed
      startTime: '08:00',
      endTime: '14:00',
      periodSlots: [
        { start: '08:00', end: '08:45' },
        { start: '08:50', end: '09:35' },
        { start: '09:40', end: '10:25' },
        { start: '10:45', end: '11:30' },
        { start: '11:35', end: '12:20' },
        { start: '12:25', end: '13:10' }
      ],
      // timetable[day_periodIndex] = subjectName
      timetable: {}
    },
    subjects: [
      { id: 's1', name: 'ریاضی', color: 'math' },
      { id: 's2', name: 'فیزیک', color: 'physics' },
      { id: 's3', name: 'شیمی', color: 'chem' },
      { id: 's4', name: 'زیست', color: 'bio' },
      { id: 's5', name: 'انگلیسی', color: 'english' }
    ],
    tasks: [],
    exams: [],
    goals: [],
    notes: [],
    events: [],
    studySessions: [],
    notifications: [],
    grades: [],
    activityLog: [],
    generatedPlans: [],
    habits: { studyDates: [], currentStreak: 0, bestStreak: 0 },
    dailyStudyGoalMin: 90,
    weeklyFocusSubject: '',
    activeTimer: null,
    currentView: 'dashboard'
  };

  let timerInterval = null;
  let clockInterval = null;
  let deletedItem = null;
  let undoTimeout = null;

  // -------------------- Persistence --------------------
  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const saved = JSON.parse(raw);
        state = { ...state, ...saved };
        if (!state.habits) state.habits = { studyDates: [], currentStreak: 0, bestStreak: 0 };
        if (!state.grades) state.grades = [];
        if (!state.activityLog) state.activityLog = [];
        if (!state.generatedPlans) state.generatedPlans = [];
        if (!state.dailyStudyGoalMin) state.dailyStudyGoalMin = 90;
        // Restore active timer with accurate remaining time
        if (state.activeTimer && !state.activeTimer.isPaused) {
          const elapsed = Date.now() - state.activeTimer.startTs - (state.activeTimer.pausedMs || 0);
          state.activeTimer.remainingMs = Math.max(0, state.activeTimer.durationMs - elapsed);
          if (state.activeTimer.remainingMs <= 0) {
            handleTimerComplete();
          }
        }
      }
    } catch (e) {
      console.warn('Load failed', e);
    }
  }

  function saveState() {
    try {
      const toSave = { ...state };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
    } catch (e) {
      toast('ذخیره اطلاعات انجام نشد.', 'error');
    }
  }

  // -------------------- Date / Time --------------------
  function getJalali(date = new Date()) {
    try {
      if (typeof jalaali !== 'undefined' && jalaali.toJalaali) {
        const j = jalaali.toJalaali(date.getFullYear(), date.getMonth() + 1, date.getDate());
        return { jy: j.jy, jm: j.jm, jd: j.jd };
      }
    } catch (e) {}
    // Approximate fallback (good enough for display)
    const g = date;
    // Rough conversion around current years
    const jy = g.getFullYear() - 621;
    const jm = ((g.getMonth() + 9) % 12) + 1;
    const jd = g.getDate();
    return { jy: jy > 1400 ? jy : 1405, jm, jd };
  }

  function formatJalaliDate(date = new Date()) {
    const j = getJalali(date);
    const dayName = DAYS_FA[date.getDay()];
    return `${dayName}، ${j.jd} ${MONTHS_FA[j.jm - 1]} ${j.jy}`;
  }

  function formatGregorianDate(date = new Date()) {
    return `${MONTHS_EN[date.getMonth()]} ${date.getDate()}, ${date.getFullYear()}`;
  }

  function updateClock() {
    const now = new Date();
    const h = pad(now.getHours());
    const m = pad(now.getMinutes());
    const s = pad(now.getSeconds());
    const clockEl = $('#liveClock');
    if (clockEl) clockEl.textContent = `${h}:${m}:${s}`;

    const jalaliEl = $('#dateJalali');
    const gregEl = $('#dateGregorian');
    if (jalaliEl) jalaliEl.textContent = formatJalaliDate(now);
    if (gregEl) gregEl.textContent = formatGregorianDate(now);

    updateGreeting(now);
    updateDayStatus(now);
    updateHeaderTimer();
  }

  function updateGreeting(now) {
    const hour = now.getHours();
    let greet = 'سلام';
    if (hour >= 5 && hour < 12) greet = 'صبح بخیر';
    else if (hour >= 12 && hour < 17) greet = 'ظهر بخیر';
    else if (hour >= 17 && hour < 21) greet = 'عصر بخیر';
    else greet = 'شب بخیر';

    const name = state.user.name || 'دوست';
    const el = $('#greetingText');
    if (el) el.textContent = `${greet}، ${name}`;
  }

  function updateDayStatus(now) {
    const el = $('#dayStatus');
    if (!el) return;
    const day = now.getDay();
    const timeStr = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
    const isSchoolDay = state.school.days.includes(day);
    const start = state.school.startTime;
    const end = state.school.endTime;

    el.classList.remove('school', 'finished');
    if (isSchoolDay && timeStr >= start && timeStr < end) {
      el.classList.add('school');
      el.querySelector('.status-text').textContent = 'در مدرسه';
    } else if (isSchoolDay && timeStr >= end) {
      el.classList.add('finished');
      el.querySelector('.status-text').textContent = 'مدرسه تمام شد';
    } else if (isSchoolDay) {
      el.querySelector('.status-text').textContent = 'قبل از مدرسه';
    } else {
      el.querySelector('.status-text').textContent = 'روز تعطیل';
    }
  }

  // -------------------- Theme --------------------
  function applyTheme() {
    const t = state.settings.theme || 'neon';
    let theme = t;
    if (t === 'system') {
      theme = window.matchMedia('(prefers-color-scheme: light)').matches ? 'gold' : 'neon';
    }
    // neon = default root (phosphor green + black)
    if (theme === 'neon') {
      document.documentElement.removeAttribute('data-theme');
    } else {
      document.documentElement.setAttribute('data-theme', theme);
    }
  }

  // -------------------- Toast & Undo --------------------
  function toast(msg, type = 'info', undoFn = null) {
    const container = $('#toastContainer');
    const el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = `<span>${msg}</span>`;
    if (undoFn) {
      const btn = document.createElement('button');
      btn.className = 'toast-undo';
      btn.textContent = 'بازگردانی';
      btn.onclick = () => {
        undoFn();
        el.classList.add('leaving');
        setTimeout(() => el.remove(), 250);
      };
      el.appendChild(btn);
    }
    container.appendChild(el);
    setTimeout(() => {
      el.classList.add('leaving');
      setTimeout(() => el.remove(), 250);
    }, undoFn ? 5000 : 3000);
  }

  // -------------------- Notifications --------------------
  function addNotification(text) {
    state.notifications.unshift({
      id: uid(),
      text,
      time: Date.now(),
      read: false
    });
    if (state.notifications.length > 50) state.notifications.pop();
    saveState();
    updateNotifBadge();
  }

  function updateNotifBadge() {
    const badge = $('#notifBadge');
    const unread = state.notifications.filter(n => !n.read).length;
    if (badge) {
      if (unread > 0) {
        badge.textContent = unread > 9 ? '9+' : unread;
        badge.classList.remove('hidden');
      } else {
        badge.classList.add('hidden');
      }
    }
  }

  function renderNotifs() {
    const list = $('#notifList');
    if (!list) return;
    if (!state.notifications.length) {
      list.innerHTML = '<div class="notif-empty">اعلانی وجود ندارد</div>';
      return;
    }
    list.innerHTML = state.notifications.map(n => `
      <div class="notif-item">
        <div>${n.text}</div>
        <div class="time">${new Date(n.time).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}</div>
      </div>
    `).join('');
  }

  // -------------------- Timer System --------------------
  function startTaskTimer(taskId) {
    const task = state.tasks.find(t => t.id === taskId);
    if (!task) return;

    if (state.activeTimer && state.activeTimer.taskId !== taskId) {
      if (!confirm('یک تایمر در حال اجراست. آیا می‌خواهی آن را متوقف کنی و تایمر جدید را شروع کنی؟')) {
        return;
      }
      stopTimer(false);
    }

    const durationMin = task.duration || 25;
    state.activeTimer = {
      taskId,
      startTs: Date.now(),
      durationMs: durationMin * 60 * 1000,
      pausedMs: 0,
      isPaused: false,
      remainingMs: durationMin * 60 * 1000
    };
    task.status = 'in-progress';
    saveState();
    startTimerLoop();
    renderCurrentView();
    toast(`تایمر «${task.title}» شروع شد`);
  }

  function startTimerLoop() {
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(() => {
      updateTimerUrgency();
      if (!state.activeTimer || state.activeTimer.isPaused) return;
      const elapsed = Date.now() - state.activeTimer.startTs - (state.activeTimer.pausedMs || 0);
      state.activeTimer.remainingMs = Math.max(0, state.activeTimer.durationMs - elapsed);
      updateHeaderTimer();
      updateActiveTimerUI();
      if (state.activeTimer.remainingMs <= 0) {
        handleTimerComplete();
      }
    }, 250);
  }

  function pauseTimer() {
    if (!state.activeTimer || state.activeTimer.isPaused) return;
    state.activeTimer.isPaused = true;
    state.activeTimer.pauseStart = Date.now();
    saveState();
    updateActiveTimerUI();
    updateHeaderTimer();
  }

  function resumeTimer() {
    if (!state.activeTimer || !state.activeTimer.isPaused) return;
    state.activeTimer.pausedMs += Date.now() - (state.activeTimer.pauseStart || Date.now());
    state.activeTimer.isPaused = false;
    delete state.activeTimer.pauseStart;
    saveState();
    startTimerLoop();
    updateActiveTimerUI();
  }

  function resetTimer() {
    if (!state.activeTimer) return;
    state.activeTimer.startTs = Date.now();
    state.activeTimer.pausedMs = 0;
    state.activeTimer.isPaused = false;
    state.activeTimer.remainingMs = state.activeTimer.durationMs;
    saveState();
    startTimerLoop();
    updateActiveTimerUI();
  }

  function stopTimer(complete = false) {
    if (!state.activeTimer) return;
    const task = state.tasks.find(t => t.id === state.activeTimer.taskId);
    const planned = state.activeTimer.durationMs / 60000;
    const actual = (state.activeTimer.durationMs - state.activeTimer.remainingMs) / 60000;

    if (actual > 0.5) {
      markStudyDay(new Date().toISOString().slice(0, 10));
      state.studySessions.push({
        id: uid(),
        taskId: state.activeTimer.taskId,
        subject: task ? task.subject : '',
        plannedMin: planned,
        actualMin: Math.round(actual * 10) / 10,
        date: new Date().toISOString().slice(0, 10),
        timestamp: Date.now()
      });
      logActivity('study', 'مطالعه ' + Math.round(actual) + ' دقیقه' + (task && task.subject ? ' · ' + task.subject : '') + (task ? ' · ' + task.title : ''), {});
    }

    if (complete && task) {
      task.status = 'completed';
      task.completedAt = Date.now();
    } else if (task && task.status === 'in-progress') {
      task.status = 'pending';
    }

    state.activeTimer = null;
    if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
    saveState();
    updateHeaderTimer();
    renderCurrentView();
  }

  function handleTimerComplete() {
    if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
    playTimerSound();
    const task = state.tasks.find(t => t.id === state.activeTimer?.taskId);
    const taskName = task ? task.title : 'تسک';
    addNotification(`زمان تسک «${taskName}» تمام شد.`);
    toast(`زمان این تسک تمام شد.`, 'info');

    // Ask completion
    openModal(`
      <div class="modal-header">
        <h2 class="modal-title">زمان تمام شد</h2>
        <button class="btn-icon" onclick="closeModal()" aria-label="بستن">✕</button>
      </div>
      <div class="modal-body">
        <p style="text-align:center;margin-bottom:1.5rem">آیا تسک «${taskName}» را کامل کردی؟</p>
        <div style="display:flex;gap:0.75rem;justify-content:center">
          <button class="btn btn-primary" id="timerCompleteYes">بله، کامل شد</button>
          <button class="btn btn-secondary" id="timerCompleteNo">هنوز ادامه دارد</button>
        </div>
      </div>
    `);
    $('#timerCompleteYes')?.addEventListener('click', () => {
      stopTimer(true);
      closeModal();
      toast('تسک با موفقیت انجام شد ✓');
    });
    $('#timerCompleteNo')?.addEventListener('click', () => {
      stopTimer(false);
      closeModal();
    });
  }

  function playTimerSound() {
    if (!state.settings.soundEnabled) return;
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 880;
      gain.gain.value = state.settings.soundVolume * 0.3;
      osc.start();
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
      osc.stop(ctx.currentTime + 0.5);
    } catch (e) {}
  }

  function updateHeaderTimer() {
    const ind = $('#headerTimerIndicator');
    const timeEl = $('#headerTimerTime');
    if (!ind || !timeEl) return;
    if (state.activeTimer) {
      ind.classList.remove('hidden');
      timeEl.textContent = formatTime(state.activeTimer.remainingMs);
    } else {
      ind.classList.add('hidden');
    }
  }

  function updateActiveTimerUI() {
    const display = $('#activeTimerDisplay');
    if (display && state.activeTimer) {
      display.textContent = formatTime(state.activeTimer.remainingMs);
    }
    // Also update task list timers if present
    $$('.task-timer-active').forEach(el => {
      if (state.activeTimer) el.textContent = formatTime(state.activeTimer.remainingMs);
    });
  }

  // -------------------- Modal --------------------
  function openModal(html) {
    const overlay = $('#modalOverlay');
    const modal = $('#modal');
    modal.innerHTML = html;
    overlay.classList.remove('hidden');
    requestAnimationFrame(() => overlay.classList.add('open'));
  }

  function closeModal() {
    const overlay = $('#modalOverlay');
    overlay.classList.remove('open');
    setTimeout(() => {
      overlay.classList.add('hidden');
      $('#modal').innerHTML = '';
    }, 220);
  }

  // -------------------- Task CRUD --------------------
  function openTaskModal(task = null) {
    const isEdit = !!task;
    const subjectsOpts = state.subjects.map(s =>
      `<option value="${s.name}" ${task?.subject === s.name ? 'selected' : ''}>${s.name}</option>`
    ).join('');

    openModal(`
      <div class="modal-header">
        <h2 class="modal-title">${isEdit ? 'ویرایش تسک' : 'تسک جدید'}</h2>
        <button class="btn-icon" onclick="closeModal()" aria-label="بستن">✕</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">عنوان</label>
          <input class="form-input" id="taskTitle" value="${task?.title || ''}" placeholder="مثلاً حل تمرین ریاضی" autofocus />
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">درس</label>
            <select class="form-select" id="taskSubject">
              <option value="">—</option>
              ${subjectsOpts}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">اولویت</label>
            <div class="priority-selector" id="taskPriority">
              <button type="button" class="priority-opt low ${!task || task.priority === 'low' ? 'active' : ''}" data-p="low">کم</button>
              <button type="button" class="priority-opt medium ${task?.priority === 'medium' ? 'active' : ''}" data-p="medium">متوسط</button>
              <button type="button" class="priority-opt high ${task?.priority === 'high' ? 'active' : ''}" data-p="high">بالا</button>
            </div>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">تاریخ</label>
            <input type="date" class="form-input" id="taskDate" value="${task?.date || new Date().toISOString().slice(0,10)}" />
          </div>
          <div class="form-group">
            <label class="form-label">ساعت</label>
            <input type="time" class="form-input" id="taskTime" value="${task?.time || ''}" />
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">مدت (دقیقه)</label>
            <input type="number" class="form-input" id="taskDuration" value="${task?.duration || 30}" min="5" max="240" />
          </div>
          <div class="form-group">
            <label class="form-label">یادآور</label>
            <input type="time" class="form-input" id="taskReminder" value="${task?.reminder || ''}" />
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">یادداشت</label>
          <textarea class="form-textarea" id="taskNotes" placeholder="توضیحات اختیاری...">${task?.notes || ''}</textarea>
        </div>
      </div>
      <div class="modal-footer">
        ${isEdit ? `<button class="btn btn-danger" id="taskDeleteBtn">حذف</button>` : ''}
        <button class="btn btn-secondary" onclick="closeModal()">انصراف</button>
        <button class="btn btn-primary" id="taskSaveBtn">${isEdit ? 'ذخیره' : 'ایجاد'}</button>
      </div>
    `);

    // Priority selector
    $$('#taskPriority .priority-opt').forEach(btn => {
      btn.addEventListener('click', () => {
        $$('#taskPriority .priority-opt').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });

    $('#taskSaveBtn').onclick = () => {
      const title = $('#taskTitle').value.trim();
      if (!title) { toast('عنوان تسک را وارد کن'); return; }
      const priority = $('#taskPriority .priority-opt.active')?.dataset.p || 'low';
      const data = {
        title,
        subject: $('#taskSubject').value,
        priority,
        date: $('#taskDate').value,
        time: $('#taskTime').value,
        duration: parseInt($('#taskDuration').value) || 30,
        reminder: $('#taskReminder').value,
        notes: $('#taskNotes').value,
        status: task?.status || 'pending'
      };
      if (isEdit) {
        Object.assign(task, data);
        toast('تسک به‌روزرسانی شد');
      } else {
        state.tasks.unshift({ id: uid(), createdAt: Date.now(), ...data });
        toast('تسک ایجاد شد');
      }
      saveState();
      closeModal();
      renderCurrentView();
    };

    if (isEdit) {
      $('#taskDeleteBtn').onclick = () => {
        const idx = state.tasks.findIndex(t => t.id === task.id);
        if (idx > -1) {
          const removed = state.tasks.splice(idx, 1)[0];
          saveState();
          closeModal();
          renderCurrentView();
          toast('تسک حذف شد', 'info', () => {
            state.tasks.splice(idx, 0, removed);
            saveState();
            renderCurrentView();
          });
        }
      };
    }
  }

  function toggleTaskComplete(taskId) {
    const task = state.tasks.find(t => t.id === taskId);
    if (!task) return;
    if (task.status === 'completed') {
      task.status = 'pending';
      delete task.completedAt;
    } else {
      task.status = 'completed';
      task.completedAt = Date.now();
      spawnConfetti();
      logActivity('task', 'تسک انجام شد: ' + task.title, { taskId: task.id });
    }
    saveState();
    renderCurrentView();
  }

  // -------------------- Exam CRUD --------------------
  function openExamModal(exam = null) {
    const isEdit = !!exam;
    const subjectsOpts = state.subjects.map(s =>
      `<option value="${s.name}" ${exam?.subject === s.name ? 'selected' : ''}>${s.name}</option>`
    ).join('');

    openModal(`
      <div class="modal-header">
        <h2 class="modal-title">${isEdit ? 'ویرایش امتحان' : 'امتحان جدید'}</h2>
        <button class="btn-icon" onclick="closeModal()">✕</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">نام درس / امتحان</label>
          <input class="form-input" id="examName" value="${exam?.name || ''}" placeholder="مثلاً فیزیک میان‌ترم" autofocus />
        </div>
        <div class="form-group">
          <label class="form-label">درس مرتبط</label>
          <select class="form-select" id="examSubject">
            <option value="">—</option>
            ${subjectsOpts}
          </select>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">تاریخ</label>
            <input type="date" class="form-input" id="examDate" value="${exam?.date || ''}" />
          </div>
          <div class="form-group">
            <label class="form-label">ساعت</label>
            <input type="time" class="form-input" id="examTime" value="${exam?.time || '09:00'}" />
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">مکان</label>
          <input class="form-input" id="examLocation" value="${exam?.location || ''}" placeholder="اختیاری" />
        </div>
        <div class="form-group">
          <label class="form-label">مباحث / توضیحات</label>
          <textarea class="form-textarea" id="examTopics">${exam?.topics || ''}</textarea>
        </div>
      </div>
      <div class="modal-footer">
        ${isEdit ? `<button class="btn btn-danger" id="examDeleteBtn">حذف</button>` : ''}
        <button class="btn btn-secondary" onclick="closeModal()">انصراف</button>
        <button class="btn btn-primary" id="examSaveBtn">${isEdit ? 'ذخیره' : 'ایجاد'}</button>
      </div>
    `);

    $('#examSaveBtn').onclick = () => {
      const name = $('#examName').value.trim();
      if (!name) { toast('نام امتحان را وارد کن'); return; }
      const data = {
        name,
        subject: $('#examSubject').value,
        date: $('#examDate').value,
        time: $('#examTime').value,
        location: $('#examLocation').value,
        topics: $('#examTopics').value,
        chapters: exam?.chapters || []
      };
      if (isEdit) {
        Object.assign(exam, data);
        toast('امتحان به‌روزرسانی شد');
      } else {
        state.exams.push({ id: uid(), createdAt: Date.now(), ...data });
        toast('امتحان ثبت شد');
      }
      saveState();
      closeModal();
      renderCurrentView();
    };

    if (isEdit) {
      $('#examDeleteBtn').onclick = () => {
        const idx = state.exams.findIndex(e => e.id === exam.id);
        if (idx > -1) {
          const removed = state.exams.splice(idx, 1)[0];
          saveState();
          closeModal();
          renderCurrentView();
          toast('امتحان حذف شد', 'info', () => {
            state.exams.splice(idx, 0, removed);
            saveState();
            renderCurrentView();
          });
        }
      };
    }
  }

  function getExamCountdown(exam) {
    if (!exam.date) return null;
    const target = new Date(`${exam.date}T${exam.time || '09:00'}:00`);
    const diff = target - new Date();
    if (diff < 0) return { days: 0, hours: 0, minutes: 0, past: true };
    const days = Math.floor(diff / 86400000);
    const hours = Math.floor((diff % 86400000) / 3600000);
    const minutes = Math.floor((diff % 3600000) / 60000);
    return { days, hours, minutes, past: false };
  }

  // -------------------- Views --------------------




  function updateTimerUrgency() {
    if (!state.activeTimer) return;
    const urgent = state.activeTimer.remainingMs < 60000 && state.activeTimer.remainingMs > 0;
    document.querySelectorAll('.timer-display, .active-timer-display, #activeTimerDisplay, #timerDisplay').forEach(el => {
      if (el) el.classList.toggle('timer-urgent', urgent);
    });
  }



  function bind3DTilt() {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    if (window.matchMedia('(max-width: 768px)').matches) return;
    if (window.matchMedia('(pointer: coarse)').matches) return;
    const els = document.querySelectorAll('.stat-card, .dash-hero-simple, .subject-card');
    els.forEach(el => {
      if (el.dataset.tiltBound) return;
      el.dataset.tiltBound = '1';
      let ticking = false;
      el.addEventListener('mousemove', e => {
        if (ticking) return;
        ticking = true;
        requestAnimationFrame(() => {
          const r = el.getBoundingClientRect();
          const x = (e.clientX - r.left) / r.width - 0.5;
          const y = (e.clientY - r.top) / r.height - 0.5;
          el.style.transform = `perspective(900px) rotateX(${(-y * 8).toFixed(2)}deg) rotateY(${(x * 10).toFixed(2)}deg) translateZ(6px)`;
          ticking = false;
        });
      }, { passive: true });
      el.addEventListener('mouseleave', () => { el.style.transform = ''; }, { passive: true });
    });
  }

  function spawnConfetti() {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const colors = ['#39ff78', '#6dff9c', '#f0c929', '#60a5fa', '#fb7185', '#a78bfa'];
    for (let i = 0; i < 10; i++) {
      const el = document.createElement('div');
      el.className = 'confetti-piece';
      el.style.left = Math.random() * 100 + 'vw';
      el.style.background = colors[i % colors.length];
      el.style.animationDelay = (Math.random() * 0.25) + 's';
      el.style.animationDuration = (1.2 + Math.random() * 0.8) + 's';
      el.style.width = (6 + Math.random() * 6) + 'px';
      el.style.height = (6 + Math.random() * 8) + 'px';
      el.style.borderRadius = Math.random() > 0.5 ? '50%' : '2px';
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 2200);
    }
  }

  function logActivity(type, message, meta = {}) {
    if (!state.activityLog) state.activityLog = [];
    state.activityLog.unshift({
      id: uid(),
      type, // study | task | exam | plan | grade | system
      message,
      meta,
      ts: Date.now()
    });
    // keep last 200
    if (state.activityLog.length > 200) state.activityLog = state.activityLog.slice(0, 200);
  }

  function generateSmartPlan(days = 7) {
    const today = new Date();
    const todayStr = today.toISOString().slice(0, 10);
    const goal = state.dailyStudyGoalMin || 90;
    const subjects = state.subjects.length ? state.subjects : [{ name: 'عمومی', color: 'default' }];
    const exams = state.exams
      .filter(e => e.date && e.date >= todayStr)
      .sort((a, b) => a.date.localeCompare(b.date));

    const created = [];
    const planDays = [];

    for (let i = 0; i < days; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      const key = d.toISOString().slice(0, 10);
      const dayTasks = [];

      // Exam pressure: if exam within 3 days, focus that subject
      const nearExam = exams.find(e => {
        const diff = (new Date(e.date) - d) / 86400000;
        return diff >= 0 && diff <= 3;
      });

      let focusList = [];
      if (nearExam) {
        const sub = nearExam.subject || nearExam.name;
        focusList = [
          { title: 'مرور فشرده: ' + (nearExam.name || sub), subject: sub, duration: Math.round(goal * 0.45), priority: 'high' },
          { title: 'نمونه سؤال: ' + sub, subject: sub, duration: Math.round(goal * 0.35), priority: 'high' },
          { title: 'خلاصه نکات ضعیف', subject: sub, duration: Math.max(15, Math.round(goal * 0.2)), priority: 'medium' }
        ];
      } else {
        // rotate subjects
        const s1 = subjects[i % subjects.length];
        const s2 = subjects[(i + 1) % subjects.length];
        focusList = [
          { title: 'مطالعه اصلی: ' + s1.name, subject: s1.name, duration: Math.round(goal * 0.5), priority: i === 0 ? 'high' : 'medium' },
          { title: 'تمرین / مسئله: ' + s2.name, subject: s2.name, duration: Math.round(goal * 0.3), priority: 'medium' },
          { title: 'مرور سریع روز', subject: s1.name, duration: Math.max(15, Math.round(goal * 0.2)), priority: 'low' }
        ];
      }

      focusList.forEach(t => {
        const task = {
          id: uid(),
          title: t.title,
          subject: t.subject,
          duration: t.duration,
          priority: t.priority,
          status: 'pending',
          date: key,
          notes: 'ساخته‌شده توسط برنامه‌ساز',
          createdAt: Date.now(),
          fromPlan: true
        };
        state.tasks.push(task);
        dayTasks.push(task);
        created.push(task);
      });
      planDays.push({ date: key, tasks: dayTasks.map(t => t.title) });
    }

    const plan = {
      id: uid(),
      createdAt: Date.now(),
      days,
      dailyGoal: goal,
      summary: planDays
    };
    if (!state.generatedPlans) state.generatedPlans = [];
    state.generatedPlans.unshift(plan);
    if (state.generatedPlans.length > 20) state.generatedPlans = state.generatedPlans.slice(0, 20);

    logActivity('plan', `برنامه ${days} روزه ساخته شد (${created.length} تسک)`, { planId: plan.id });
    saveState();
    return { plan, created };
  }

  function renderActivityView() {
    if (!state.activityLog) state.activityLog = [];
    const items = state.activityLog.slice(0, 80);
    const typeIcon = { study: '📚', task: '✓', exam: '📝', plan: '🗓', grade: '⭐', system: '•' };
    return `
      <div class="section-title">
        <span>پیگیری فعالیت‌ها</span>
        <button class="btn btn-secondary btn-sm" id="clearActivityBtn">پاک کردن لیست</button>
      </div>
      <p class="text-muted" style="font-size:0.85rem;margin-bottom:1rem">همه کارهایی که انجام می‌دهی اینجا ثبت می‌شود تا پیشرفتت را ببینی.</p>
      <div class="card">
        ${items.length ? `
          <div class="activity-timeline">
            ${items.map(a => {
              const d = new Date(a.ts);
              const time = String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0');
              const day = d.toISOString().slice(0, 10);
              return `
                <div class="activity-item type-${a.type || 'system'}">
                  <div class="activity-dot"></div>
                  <div class="activity-body">
                    <div class="activity-msg">${a.message}</div>
                    <div class="activity-meta">${day} · ${time}</div>
                  </div>
                </div>`;
            }).join('')}
          </div>
        ` : '<div class="empty-state"><h3>هنوز فعالیتی ثبت نشده</h3><p>با انجام تسک، مطالعه یا ساخت برنامه، اینجا پر می‌شود</p></div>'}
      </div>
    `;
  }

  function renderPlanBuilderView() {
    const last = (state.generatedPlans || [])[0];
    return `
      <div class="section-title"><span>برنامه‌ساز هوشمند</span></div>
      <div class="card mb-2" style="border-color:var(--accent)">
        <p style="margin:0 0 0.75rem;color:var(--text-secondary);font-size:0.9rem;line-height:1.7">
          بر اساس <b>درس‌ها</b>، <b>امتحان‌های نزدیک</b> و <b>هدف روزانه (${state.dailyStudyGoalMin || 90} دقیقه)</b>
          یک برنامه واقعی می‌سازد و تسک‌ها را در تقویم و لیست کارها ثبت می‌کند.
        </p>
        <div style="display:flex;flex-wrap:wrap;gap:0.5rem;margin-bottom:1rem">
          <button class="btn btn-primary" data-gen-plan="3">برنامه ۳ روزه</button>
          <button class="btn btn-primary" data-gen-plan="7">برنامه ۷ روزه</button>
          <button class="btn btn-secondary" data-gen-plan="14">برنامه ۱۴ روزه</button>
        </div>
        <div class="text-muted" style="font-size:0.8rem">
          اگر امتحان نزدیکی داشته باشی، روزهای قبل از آن روی همان درس متمرکز می‌شود.
        </div>
      </div>
      ${last ? `
        <div class="section-title"><span>آخرین برنامه ساخته‌شده</span></div>
        <div class="card">
          <div class="text-muted" style="font-size:0.8rem;margin-bottom:0.75rem">
            ${new Date(last.createdAt).toLocaleString('fa-IR')} · ${last.days} روز · هدف روزانه ${last.dailyGoal}د
          </div>
          ${(last.summary || []).slice(0, 7).map(d => `
            <div class="plan-day-block">
              <strong>${d.date}</strong>
              <ul style="margin:0.35rem 0 0.75rem 0;padding-right:1.1rem;color:var(--text-secondary);font-size:0.85rem">
                ${(d.tasks || []).map(t => `<li>${t}</li>`).join('')}
              </ul>
            </div>
          `).join('')}
        </div>
      ` : ''}
    `;
  }


  function ensureHabits() {
    if (!state.habits) state.habits = { studyDates: [], currentStreak: 0, bestStreak: 0 };
    if (!Array.isArray(state.habits.studyDates)) state.habits.studyDates = [];
  }

  function markStudyDay(dateStr) {
    ensureHabits();
    if (!state.habits.studyDates.includes(dateStr)) {
      state.habits.studyDates.push(dateStr);
      state.habits.studyDates.sort();
    }
    // recompute streak ending today or yesterday
    let streak = 0;
    let d = new Date();
    for (let i = 0; i < 400; i++) {
      const key = d.toISOString().slice(0, 10);
      if (state.habits.studyDates.includes(key)) {
        streak++;
        d.setDate(d.getDate() - 1);
      } else if (i === 0) {
        // allow streak to count if last study was yesterday
        d.setDate(d.getDate() - 1);
        continue;
      } else break;
    }
    state.habits.currentStreak = streak;
    if (streak > (state.habits.bestStreak || 0)) state.habits.bestStreak = streak;
  }

  function getStudyMinutesOn(dateStr) {
    return state.studySessions.filter(s => s.date === dateStr).reduce((a, b) => a + (b.actualMin || 0), 0);
  }

  function getSmartSuggestions() {
    const today = new Date().toISOString().slice(0, 10);
    const tips = [];
    const pending = state.tasks.filter(t => t.status !== 'completed');
    const high = pending.filter(t => t.priority === 'high');
    const exams = state.exams.filter(e => e.date && e.date >= today).sort((a, b) => a.date.localeCompare(b.date));
    const goal = state.dailyStudyGoalMin || 90;
    const studied = getStudyMinutesOn(today);
    if (high.length) tips.push({ type: 'warn', text: `${high.length} تسک با اولویت بالا باز است — اول آن‌ها را ببند.` });
    if (exams[0]) {
      const days = Math.ceil((new Date(exams[0].date) - new Date(today)) / 86400000);
      if (days <= 7) tips.push({ type: 'exam', text: `امتحان «${exams[0].name}» تا ${days} روز دیگر — هر روز مرور کوتاه بگذار.` });
    }
    if (studied < goal) tips.push({ type: 'goal', text: `هدف روزانه ${goal} دقیقه؛ امروز ${Math.round(studied)} دقیقه خوانده‌ای (${Math.max(0, goal - Math.round(studied))} دقیقه مانده).` });
    else tips.push({ type: 'ok', text: `آفرین! هدف روزانه مطالعه را زدی.` });
    ensureHabits();
    if ((state.habits.currentStreak || 0) >= 3) tips.push({ type: 'streak', text: `استریک ${state.habits.currentStreak} روزه — ادامه بده تا رکورد ${state.habits.bestStreak || state.habits.currentStreak} را بشکنی.` });
    if (!tips.length) tips.push({ type: 'ok', text: 'همه‌چیز مرتب است. یک هدف یا تسک جدید تعریف کن.' });
    return tips.slice(0, 4);
  }

  function applyStudyTemplate(type) {
    const today = new Date().toISOString().slice(0, 10);
    const templates = {
      pomodoro: [
        { title: 'بلوک تمرکز ۱ (۲۵د)', duration: 25 },
        { title: 'استراحت کوتاه', duration: 5 },
        { title: 'بلوک تمرکز ۲ (۲۵د)', duration: 25 },
        { title: 'استراحت کوتاه', duration: 5 },
        { title: 'بلوک تمرکز ۳ (۲۵د)', duration: 25 }
      ],
      exam_week: [
        { title: 'مرور خلاصه‌ها', duration: 40 },
        { title: 'حل نمونه سؤال', duration: 45 },
        { title: 'نقاط ضعف', duration: 30 }
      ],
      light: [
        { title: 'مرور سریع نکات', duration: 20 },
        { title: 'تمرین کوتاه', duration: 25 }
      ]
    };
    const list = templates[type] || templates.light;
    list.forEach(t => {
      state.tasks.push({
        id: uid(), title: t.title, subject: '', duration: t.duration,
        priority: 'medium', status: 'pending', date: today, notes: 'قالب آماده', createdAt: Date.now()
      });
    });
    saveState();
    toast('قالب به تسک‌های امروز اضافه شد');
    renderCurrentView();
  }

  function requestNotifyPermission() {
    if (!('Notification' in window)) { toast('مرورگر اعلان را پشتیبانی نمی‌کند'); return; }
    Notification.requestPermission().then(p => {
      state.settings.notifications = p === 'granted';
      saveState();
      toast(p === 'granted' ? 'اعلان‌ها فعال شد' : 'اجازه اعلان داده نشد');
    });
  }

  function notifyUser(title, body) {
    if (!state.settings.notifications || !('Notification' in window) || Notification.permission !== 'granted') return;
    try { new Notification(title, { body, icon: 'icons/icon-192.png' }); } catch (e) {}
  }

  function exportData() {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'personal-study-os-backup-' + new Date().toISOString().slice(0, 10) + '.json';
    a.click();
    URL.revokeObjectURL(a.href);
    toast('پشتیبان دانلود شد');
  }

  function importData(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (!data || typeof data !== 'object') throw new Error('bad');
        state = { ...state, ...data };
        if (!state.habits) state.habits = { studyDates: [], currentStreak: 0, bestStreak: 0 };
        if (!state.grades) state.grades = [];
        if (!state.activityLog) state.activityLog = [];
        if (!state.generatedPlans) state.generatedPlans = [];
        saveState();
        applyTheme();
        renderCurrentView();
        toast('داده‌ها با موفقیت وارد شد');
      } catch (e) {
        toast('فایل نامعتبر است');
      }
    };
    reader.readAsText(file);
  }


  function renderDashboard() {
    ensureHabits();
    const today = new Date().toISOString().slice(0, 10);
    const todayTasks = state.tasks.filter(t => t.date === today || (!t.date && t.status !== 'completed'));
    const completed = todayTasks.filter(t => t.status === 'completed').length;
    const total = todayTasks.length || 1;
    const progress = Math.round((completed / total) * 100);

    const upcomingExams = state.exams
      .filter(e => e.date && new Date(e.date) >= new Date(today))
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(0, 3);

    const studyToday = state.studySessions
      .filter(s => s.date === today)
      .reduce((sum, s) => sum + s.actualMin, 0);

    const circumference = 2 * Math.PI * 38;
    const offset = circumference - (progress / 100) * circumference;

    let activeTimerHTML = '';
    if (state.activeTimer) {
      const task = state.tasks.find(t => t.id === state.activeTimer.taskId);
      activeTimerHTML = `
        <div class="active-timer-card">
          <div class="active-timer-info">
            <div class="active-timer-label">تایمر فعال</div>
            <div class="active-timer-name">${task?.title || 'تسک'}</div>
            <div class="active-timer-display" id="activeTimerDisplay">${formatTime(state.activeTimer.remainingMs)}</div>
          </div>
          <div class="active-timer-controls">
            <button class="btn btn-secondary btn-sm" id="dashPauseTimer">${state.activeTimer.isPaused ? 'ادامه' : 'توقف'}</button>
            <button class="btn btn-primary btn-sm" id="dashFinishTimer">اتمام</button>
          </div>
        </div>
      `;
    }

    // Simple schedule based on school + tasks
    const scheduleItems = buildTodaySchedule();

    const userName = state.user.name || 'دانش‌آموز';
    return `
      <div class="dash-hero dash-hero-simple">
        <div class="dash-hero-overlay">
          <h2>سلام، ${userName}</h2>
          <p>امروز برای موفقیتت برنامه‌ریزی کن · Personal Study OS</p>
        </div>
      </div>
      ${activeTimerHTML}
      <div class="overview-row">
        <div class="stat-card">
          <span class="stat-label">مدرسه</span>
          <span class="stat-value">${state.school.startTime} – ${state.school.endTime}</span>
        </div>
        <div class="stat-card">
          <span class="stat-label">تسک‌ها</span>
          <span class="stat-value">${todayTasks.length}</span>
        </div>
        <div class="stat-card">
          <span class="stat-label">انجام‌شده</span>
          <span class="stat-value success">${completed}</span>
        </div>
        <div class="stat-card">
          <span class="stat-label">مطالعه امروز</span>
          <span class="stat-value accent">${formatDuration(Math.round(studyToday))}</span>
        </div>
        <div class="stat-card">
          <span class="stat-label">امتحان بعدی</span>
          <span class="stat-value warning">${upcomingExams[0] ? getExamCountdown(upcomingExams[0])?.days + ' روز' : '—'}</span>
        </div>
        <div class="stat-card">
          <span class="stat-label">پیشرفت</span>
          <span class="stat-value">${progress}٪</span>
        </div>
      </div>


      <div class="overview-row" style="margin-top:0.25rem">
        <div class="stat-card">
          <span class="stat-label">استریک مطالعه</span>
          <span class="stat-value accent">${(state.habits && state.habits.currentStreak) || 0} روز</span>
        </div>
        <div class="stat-card">
          <span class="stat-label">بهترین استریک</span>
          <span class="stat-value">${(state.habits && state.habits.bestStreak) || 0} روز</span>
        </div>
        <div class="stat-card">
          <span class="stat-label">هدف روزانه</span>
          <span class="stat-value">${Math.min(100, Math.round((studyToday / (state.dailyStudyGoalMin || 90)) * 100))}٪</span>
        </div>
      </div>

      <div class="card mb-2">
        <div class="section-title"><span>پیشنهاد هوشمند</span></div>
        <div class="insights">
          ${getSmartSuggestions().map(t => `<div class="insight-item">${t.text}</div>`).join('')}
        </div>
      </div>

      <div class="card mb-2">
        <div class="section-title"><span>شروع سریع با قالب</span></div>
        <div style="display:flex;flex-wrap:wrap;gap:0.5rem">
          <button class="btn btn-secondary btn-sm" data-template="pomodoro">پومودورو (۳ بلوک)</button>
          <button class="btn btn-secondary btn-sm" data-template="exam_week">هفته امتحان</button>
          <button class="btn btn-secondary btn-sm" data-template="light">مرور سبک</button>
        </div>
      </div>

      <div class="dash-grid">
        <div class="card">
          <div class="section-title">
            <span>پیشرفت امروز</span>
          </div>
          <div class="progress-ring-wrap">
            <div class="progress-ring">
              <svg viewBox="0 0 88 88">
                <circle class="ring-bg" cx="44" cy="44" r="38"></circle>
                <circle class="ring-fg" cx="44" cy="44" r="38"
                  stroke-dasharray="${circumference}"
                  stroke-dashoffset="${offset}"></circle>
              </svg>
              <div class="ring-text">${progress}٪</div>
            </div>
            <div>
              <div style="font-size:1.25rem;font-weight:700">${completed} / ${todayTasks.length} تسک</div>
              <div class="text-muted" style="font-size:0.85rem;margin-top:0.25rem">امروز انجام شده</div>
            </div>
          </div>
        </div>

        <div class="card dash-span-2">
          <div class="section-title">
            <span>برنامه امروز</span>
          </div>
          <div class="timeline">
            ${scheduleItems.length ? scheduleItems.map(item => `
              <div class="timeline-item ${item.current ? 'current' : ''} ${item.done ? 'done' : ''}">
                <div class="timeline-time">${item.time}</div>
                <div class="timeline-title">${item.title}</div>
                ${item.meta ? `<div class="timeline-meta">${item.meta}</div>` : ''}
              </div>
            `).join('') : '<div class="empty-state" style="padding:1.5rem"><p>برنامه‌ای برای امروز ثبت نشده</p></div>'}
          </div>
        </div>

        <div class="card">
          <div class="section-title">
            <span>تسک‌های امروز</span>
            <button class="btn-text" onclick="openTaskModal()">+ جدید</button>
          </div>
          <div class="task-list">
            ${todayTasks.length ? todayTasks.slice(0, 6).map(t => renderTaskItem(t)).join('') :
              `<div class="empty-state" style="padding:1.5rem">
                <div class="empty-illustration" style="width:90px;height:90px">
                  <svg viewBox="0 0 120 120" fill="none">
                    <rect x="25" y="20" width="70" height="80" rx="10" stroke="url(#taskG)" stroke-width="2.5" opacity="0.5"/>
                    <path d="M40 45h40M40 60h30M40 75h35" stroke="url(#taskG)" stroke-width="2.5" stroke-linecap="round" opacity="0.7"/>
                    <circle cx="85" cy="35" r="14" fill="url(#taskG)" opacity="0.9"/>
                    <path d="M80 35l4 4 8-8" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <defs><linearGradient id="taskG" x1="20" y1="15" x2="100" y2="100"><stop stop-color="#6366f1"/><stop offset="1" stop-color="#22d3ee"/></linearGradient></defs>
                  </svg>
                </div>
                <h3>تسکی نیست</h3>
                <p>اولین تسک امروزت را اضافه کن</p>
              </div>`}
          </div>
        </div>

        <div class="card">
          <div class="section-title">
            <span>امتحانات نزدیک</span>
            <button class="btn-text" onclick="openExamModal()">+ جدید</button>
          </div>
          <div class="exam-list">
            ${upcomingExams.length ? upcomingExams.map(e => {
              const cd = getExamCountdown(e);
              return `
                <div class="exam-card" data-exam-id="${e.id}">
                  <div class="exam-countdown">
                    <div class="exam-days">${cd?.past ? 'گذشت' : cd?.days ?? '—'}</div>
                    <div class="exam-days-label">${cd?.past ? '' : 'روز'}</div>
                  </div>
                  <div class="exam-info">
                    <div class="exam-name">${e.name}</div>
                    <div class="exam-meta">${e.subject || ''} ${e.date ? '• ' + e.date : ''}</div>
                  </div>
                </div>
              `;
            }).join('') : '<div class="empty-state" style="padding:1.5rem"><p>امتحانی ثبت نشده</p></div>'}
          </div>
        </div>
      </div>
    `;
  }

  function buildTodaySchedule() {
    const items = [];
    const now = new Date();
    const timeStr = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
    const day = now.getDay();
    const isSchoolDay = state.school.days.includes(day);

    if (isSchoolDay) {
      items.push({
        time: state.school.startTime,
        title: 'مدرسه',
        meta: `تا ${state.school.endTime}`,
        current: timeStr >= state.school.startTime && timeStr < state.school.endTime,
        done: timeStr >= state.school.endTime
      });
    }

    const today = new Date().toISOString().slice(0, 10);
    state.tasks
      .filter(t => t.date === today && t.time && t.status !== 'completed')
      .sort((a, b) => (a.time || '').localeCompare(b.time || ''))
      .forEach(t => {
        items.push({
          time: t.time,
          title: t.title,
          meta: t.subject || '',
          current: false,
          done: false
        });
      });

    return items;
  }

  function renderTaskItem(t) {
    const isActive = state.activeTimer?.taskId === t.id;
    const isCompleted = t.status === 'completed';
    return `
      <div class="task-item ${isCompleted ? 'completed' : ''} ${t.status === 'in-progress' ? 'in-progress' : ''}" data-task-id="${t.id}">
        <div class="task-check ${isCompleted ? 'checked' : ''}" data-action="toggle" data-id="${t.id}">
          <svg viewBox="0 0 24 24" fill="none"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <div class="task-body">
          <div class="task-title">${t.title}</div>
          <div class="task-meta">
            ${t.subject ? `<span class="task-tag">${t.subject}</span>` : ''}
            ${t.time ? `<span>${t.time}</span>` : ''}
            ${t.duration ? `<span>${t.duration}د</span>` : ''}
            <span class="priority-${t.priority || 'low'}">${t.priority === 'high' ? 'بالا' : t.priority === 'medium' ? 'متوسط' : 'کم'}</span>
          </div>
        </div>
        <div class="task-actions">
          ${isActive
            ? `<span class="task-timer-active">${formatTime(state.activeTimer.remainingMs)}</span>`
            : `<button class="task-timer-btn" data-action="start-timer" data-id="${t.id}">شروع</button>`
          }
        </div>
      </div>
    `;
  }

  function renderTasksView() {
    const pending = state.tasks.filter(t => t.status !== 'completed');
    const completed = state.tasks.filter(t => t.status === 'completed');
    return `
      <div class="section-title">
        <span>تسک‌ها</span>
        <button class="btn btn-primary btn-sm" onclick="openTaskModal()">+ تسک جدید</button>
      </div>
      ${pending.length ? `
        <div class="task-list mb-2">
          ${pending.map(t => renderTaskItem(t)).join('')}
        </div>
      ` : `<div class="empty-state">
        <svg viewBox="0 0 24 24"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
        <h3>هیچ تسک بازی وجود ندارد</h3>
        <p>تسک جدید بساز و پیشرفتت را دنبال کن</p>
        <button class="btn btn-primary" onclick="openTaskModal()">ایجاد تسک</button>
      </div>`}
      ${completed.length ? `
        <div class="section-title mt-2"><span>انجام‌شده (${completed.length})</span></div>
        <div class="task-list">
          ${completed.slice(0, 10).map(t => renderTaskItem(t)).join('')}
        </div>
      ` : ''}
    `;
  }

  function renderCalendarView() {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    // Adjust for Saturday start (weekStart=6)
    const startOffset = (firstDay - state.settings.weekStart + 7) % 7;

    let daysHTML = '';
    const dayNames = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];
    // Reorder based on weekStart
    const orderedNames = [];
    for (let i = 0; i < 7; i++) {
      orderedNames.push(dayNames[(state.settings.weekStart + i) % 7]);
    }

    for (let i = 0; i < startOffset; i++) {
      daysHTML += `<div class="cal-day other-month"></div>`;
    }
    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${year}-${pad(month + 1)}-${pad(d)}`;
      const isToday = d === now.getDate();
      const hasExam = state.exams.some(e => e.date === dateStr);
      const hasTask = state.tasks.some(t => t.date === dateStr);
      daysHTML += `
        <div class="cal-day ${isToday ? 'today' : ''} ${hasExam ? 'has-exam' : ''} ${hasTask ? 'has-task' : ''}" data-date="${dateStr}">
          ${d}
        </div>`;
    }

    return `
      <div class="section-title">
        <span>تقویم</span>
      </div>
      <div class="calendar-wrap">
        <div class="cal-header">
          <div class="cal-title">${MONTHS_EN[month]} ${year}</div>
          <div class="cal-nav">
            <button class="btn-icon" id="calPrev">‹</button>
            <button class="btn-icon" id="calNext">›</button>
          </div>
        </div>
        <div class="cal-grid">
          ${orderedNames.map(n => `<div class="cal-day-name">${n}</div>`).join('')}
          ${daysHTML}
        </div>
      </div>
      <div class="mt-2">
        <div class="section-title"><span>رویدادهای این ماه</span></div>
        <div class="exam-list">
          ${state.exams.filter(e => e.date && e.date.startsWith(`${year}-${pad(month+1)}`)).map(e => `
            <div class="exam-card" data-exam-id="${e.id}">
              <div class="exam-info">
                <div class="exam-name">${e.name}</div>
                <div class="exam-meta">${e.date} ${e.time || ''}</div>
              </div>
            </div>
          `).join('') || '<p class="text-muted">رویدادی ثبت نشده</p>'}
        </div>
      </div>
    `;
  }



  function ensureSchoolShape() {
    if (!state.school.timetable) state.school.timetable = {};
    if (!state.school.periodSlots || !state.school.periodSlots.length) {
      if (state.school.periodTimes && state.school.periodTimes.length) {
        state.school.periodSlots = state.school.periodTimes.map((t, i, arr) => ({
          start: t,
          end: arr[i + 1] || state.school.endTime || '14:00'
        }));
      } else {
        state.school.periodSlots = [
          { start: '08:00', end: '08:45' },
          { start: '08:50', end: '09:35' },
          { start: '09:40', end: '10:25' },
          { start: '10:45', end: '11:30' },
          { start: '11:35', end: '12:20' },
          { start: '12:25', end: '13:10' }
        ];
      }
    }
  }

  function openPeriodSlotsModal() {
    ensureSchoolShape();
    const rows = state.school.periodSlots.map((p, i) => `
      <div class="form-row period-slot-row" data-i="${i}" style="margin-bottom:0.5rem;align-items:end">
        <div class="form-group"><label class="form-label">شروع زنگ ${i + 1}</label>
          <input type="time" class="form-input period-start" value="${p.start}" /></div>
        <div class="form-group"><label class="form-label">پایان زنگ ${i + 1}</label>
          <input type="time" class="form-input period-end" value="${p.end}" /></div>
        <button type="button" class="btn btn-danger btn-sm remove-period-row" title="حذف">✕</button>
      </div>`).join('');

    openModal(`
      <div class="modal-header">
        <h2 class="modal-title">ساعت‌بندی زنگ‌ها</h2>
        <button class="btn-icon" onclick="closeModal()">✕</button>
      </div>
      <div class="modal-body">
        <p class="text-muted" style="font-size:0.85rem;margin-bottom:0.75rem">شروع و پایان هر زنگ را خودت مشخص کن. زنگ اضافه یا حذف کن.</p>
        <div id="periodSlotsList">${rows}</div>
        <button type="button" class="btn btn-secondary btn-sm" id="addPeriodRow">+ زنگ جدید</button>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="closeModal()">انصراف</button>
        <button class="btn btn-primary" id="savePeriodSlots">ذخیره</button>
      </div>
    `);

    const list = $('#periodSlotsList');
    const bindRemove = () => {
      $$('.remove-period-row').forEach(btn => {
        btn.onclick = () => {
          if (list.children.length <= 1) { toast('حداقل یک زنگ لازم است'); return; }
          btn.closest('.period-slot-row').remove();
        };
      });
    };
    bindRemove();
    $('#addPeriodRow').onclick = () => {
      const n = list.children.length + 1;
      const div = document.createElement('div');
      div.className = 'form-row period-slot-row';
      div.style.marginBottom = '0.5rem';
      div.innerHTML = `
        <div class="form-group"><label class="form-label">شروع زنگ ${n}</label>
          <input type="time" class="form-input period-start" value="13:00" /></div>
        <div class="form-group"><label class="form-label">پایان زنگ ${n}</label>
          <input type="time" class="form-input period-end" value="13:45" /></div>
        <button type="button" class="btn btn-danger btn-sm remove-period-row">✕</button>`;
      list.appendChild(div);
      bindRemove();
    };
    $('#savePeriodSlots').onclick = () => {
      const slots = [];
      $$('.period-slot-row').forEach(row => {
        const start = row.querySelector('.period-start').value;
        const end = row.querySelector('.period-end').value;
        if (start && end) slots.push({ start, end });
      });
      if (!slots.length) { toast('حداقل یک زنگ وارد کن'); return; }
      state.school.periodSlots = slots;
      state.school.startTime = slots[0].start;
      state.school.endTime = slots[slots.length - 1].end;
      saveState();
      closeModal();
      renderCurrentView();
      toast('ساعت‌بندی زنگ‌ها ذخیره شد');
    };
  }

  function renderSchoolView() {
    const dayLabels = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه'];
    const order = [6, 0, 1, 2, 3, 4, 5];
    ensureSchoolShape();
    const slots = state.school.periodSlots;

    return `
      <div class="section-title">
        <span>برنامه مدرسه</span>
        <div class="actions">
          <button class="btn btn-secondary btn-sm" id="editSchoolHoursBtn">روزهای مدرسه</button>
          <button class="btn btn-primary btn-sm" id="editPeriodTimesBtn">ساعت‌بندی زنگ‌ها</button>
        </div>
      </div>
      <div class="card mb-2">
        <div class="flex-between mb-1">
          <span class="text-muted">بازه کلی</span>
          <span class="stat-value" style="font-size:1rem">${state.school.startTime} – ${state.school.endTime}</span>
        </div>
        <div class="flex gap-1" style="flex-wrap:wrap;margin-bottom:0.75rem">
          ${dayLabels.map((d, i) => `
            <button type="button" class="task-tag school-day-toggle" data-day="${i}"
              style="cursor:pointer;${state.school.days.includes(i) ? 'background:var(--accent-soft);color:var(--accent-hover);border:1px solid var(--accent)' : 'opacity:0.55'}">${d}</button>
          `).join('')}
        </div>
        <p class="text-muted" style="font-size:0.8rem;margin:0">ابتدا «ساعت‌بندی زنگ‌ها» را تنظیم کن، بعد روی خانه‌های جدول درس بگذار.</p>
      </div>
      <div class="section-title"><span>جدول هفتگی</span></div>
      <div class="timetable">
        <table>
          <thead>
            <tr>
              <th>زنگ</th>
              ${order.map(i => `<th>${dayLabels[i]}</th>`).join('')}
            </tr>
          </thead>
          <tbody>
            ${slots.map((slot, pi) => `
              <tr>
                <td style="font-weight:600;color:var(--text-muted);font-size:0.8rem;white-space:nowrap">${slot.start}<br/>${slot.end}</td>
                ${order.map(day => {
                  const key = day + '_' + pi;
                  const val = (state.school.timetable && state.school.timetable[key]) || '';
                  const subj = state.subjects.find(s => s.name === val);
                  const color = subj ? subj.color : 'default';
                  const isSchool = state.school.days.includes(day);
                  if (!isSchool) return '<td class="tt-disabled"></td>';
                  return `<td><button type="button" class="period-block subj-${color} tt-cell" data-key="${key}" style="width:100%;border:none;cursor:pointer">${val || '—'}</button></td>`;
                }).join('')}
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  }


  function renderExamsView() {
    const sorted = [...state.exams].sort((a, b) => (a.date || '').localeCompare(b.date || ''));
    return `
      <div class="section-title">
        <span>امتحانات</span>
        <button class="btn btn-primary btn-sm" onclick="openExamModal()">+ امتحان جدید</button>
      </div>
      <div class="exam-list">
        ${sorted.length ? sorted.map(e => {
          const cd = getExamCountdown(e);
          return `
            <div class="exam-card" data-exam-id="${e.id}" style="cursor:pointer">
              <div class="exam-countdown">
                <div class="exam-days">${cd?.past ? '✓' : cd?.days ?? '—'}</div>
                <div class="exam-days-label">${cd?.past ? 'گذشته' : 'روز'}</div>
              </div>
              <div class="exam-info">
                <div class="exam-name">${e.name}</div>
                <div class="exam-meta">
                  ${e.subject || ''} ${e.date ? '• ' + e.date : ''} ${e.time || ''}
                  ${cd && !cd.past ? `• ${cd.hours}س ${cd.minutes}د` : ''}
                </div>
              </div>
            </div>
          `;
        }).join('') : `
          <div class="empty-state">
            <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            <h3>امتحانی ثبت نشده</h3>
            <p>امتحانات نزدیک را اضافه کن تا شمارش معکوس ببینی</p>
            <button class="btn btn-primary" onclick="openExamModal()">افزودن امتحان</button>
          </div>
        `}
      </div>
    `;
  }


  function renderSubjectsView() {
    const colorOptions = ['math','physics','chem','bio','english','history','default'];
    return `
      <div class="section-title">
        <span>دروس من</span>
        <button class="btn btn-primary btn-sm" id="addSubjectBtn">+ درس جدید</button>
      </div>
      <p class="text-muted" style="margin-bottom:1rem;font-size:0.9rem">درس‌هایی که نداری حذف کن و درس‌های خودت را اضافه کن.</p>
      <div class="subjects-grid">
        ${state.subjects.map(s => {
          const taskCount = state.tasks.filter(t => t.subject === s.name).length;
          const examCount = state.exams.filter(e => e.subject === s.name).length;
          const icon = SUBJECT_ICONS[s.color] || SUBJECT_ICONS.default;
          return `
            <div class="subject-card" data-subject-id="${s.id}">
              <div class="subject-visual subj-pattern-${s.color === 'history' ? 'math' : s.color}" style="background: linear-gradient(145deg, var(--subj-${s.color})22, transparent)">
                <div class="subject-icon" style="color:var(--subj-${s.color});width:64px;height:64px;z-index:2;position:relative">
                  ${icon}
                </div>
              </div>
              <div class="subject-body">
                <div class="subject-name">${s.name}</div>
                <div class="subject-stats">
                  <span>${taskCount} تسک</span>
                  <span>${examCount} امتحان</span>
                </div>
                <div style="display:flex;gap:0.4rem;margin-top:0.75rem">
                  <button class="btn btn-secondary btn-sm edit-subject-btn" data-id="${s.id}">ویرایش</button>
                  <button class="btn btn-danger btn-sm del-subject-btn" data-id="${s.id}">حذف</button>
                </div>
              </div>
            </div>
          `;
        }).join('') || '<div class="empty-state"><h3>درسی نیست</h3><p>اولین درس را اضافه کن</p></div>'}
      </div>
    `;
  }

  function openSubjectModal(subject = null) {
    const isEdit = !!subject;
    const colors = [
      { id: 'math', name: 'بنفش' }, { id: 'physics', name: 'آبی' }, { id: 'chem', name: 'فیروزه‌ای' },
      { id: 'bio', name: 'قرمز' }, { id: 'english', name: 'نارنجی' }, { id: 'history', name: 'طلایی' }, { id: 'default', name: 'خاکستری' }
    ];
    openModal(`
      <div class="modal-header">
        <h2 class="modal-title">${isEdit ? 'ویرایش درس' : 'درس جدید'}</h2>
        <button class="btn-icon" onclick="closeModal()">✕</button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">نام درس</label>
          <input class="form-input" id="subjName" value="${subject?.name || ''}" placeholder="مثلاً ریاضی" autofocus />
        </div>
        <div class="form-group">
          <label class="form-label">رنگ</label>
          <select class="form-select" id="subjColor">
            ${colors.map(c => `<option value="${c.id}" ${subject?.color === c.id ? 'selected' : ''}>${c.name}</option>`).join('')}
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="closeModal()">انصراف</button>
        <button class="btn btn-primary" id="subjSaveBtn">${isEdit ? 'ذخیره' : 'افزودن'}</button>
      </div>
    `);
    $('#subjSaveBtn').onclick = () => {
      const name = $('#subjName').value.trim();
      if (!name) { toast('نام درس را وارد کن'); return; }
      const color = $('#subjColor').value;
      if (isEdit) {
        subject.name = name;
        subject.color = color;
        toast('درس به‌روزرسانی شد');
      } else {
        state.subjects.push({ id: uid(), name, color });
        toast('درس اضافه شد');
      }
      saveState();
      closeModal();
      renderCurrentView();
    };
  }

  function renderGoalsView() {
    return `
      <div class="section-title">
        <span>اهداف</span>
        <button class="btn btn-primary btn-sm" id="addGoalBtn">+ هدف جدید</button>
      </div>
      ${state.goals.length ? state.goals.map(g => `
        <div class="goal-item">
          <div class="goal-header">
            <div class="goal-title">${g.title}</div>
            <div class="goal-deadline">${g.deadline || ''}</div>
          </div>
          <div class="goal-progress-bar">
            <div class="goal-progress-fill" style="width:${g.progress || 0}%"></div>
          </div>
          <div class="goal-percent">${g.progress || 0}٪</div>
        </div>
      `).join('') : `
        <div class="empty-state">
          <div class="empty-illustration">
            <svg viewBox="0 0 120 120" fill="none">
              <circle cx="60" cy="60" r="50" stroke="url(#goalG)" stroke-width="2" opacity="0.35"/>
              <circle cx="60" cy="60" r="34" stroke="url(#goalG)" stroke-width="2" opacity="0.55"/>
              <circle cx="60" cy="60" r="16" fill="url(#goalG)" opacity="0.85"/>
              <defs><linearGradient id="goalG" x1="10" y1="10" x2="110" y2="110"><stop stop-color="#6366f1"/><stop offset="1" stop-color="#c084fc"/></linearGradient></defs>
            </svg>
          </div>
          <h3>هدفی تعریف نشده</h3>
          <p>اهداف تحصیلی‌ات را مشخص کن و پیشرفتت را ببین</p>
        </div>
      `}
    `;
  }

  function renderTimerView() {
    const modes = [
      { id: 'pomodoro', label: 'پومودورو', min: 25 },
      { id: 'short', label: 'استراحت کوتاه', min: 5 },
      { id: 'long', label: 'استراحت بلند', min: 15 },
      { id: 'custom', label: 'سفارشی', min: 45 }
    ];
    return `
      <div class="timer-page">
        <div class="timer-modes">
          ${modes.map(m => `<button class="timer-mode ${m.id === 'pomodoro' ? 'active' : ''}" data-mode="${m.id}" data-min="${m.min}">${m.label}</button>`).join('')}
        </div>
        <div class="timer-display-wrap">
          <svg viewBox="0 0 260 260">
            <circle class="ring-bg" cx="130" cy="130" r="120"></circle>
            <circle class="ring-fg" id="studyTimerRing" cx="130" cy="130" r="120"
              stroke-dasharray="${2 * Math.PI * 120}"
              stroke-dashoffset="0"></circle>
          </svg>
          <div class="timer-time-center">
            <div class="time" id="studyTimerDisplay">25:00</div>
            <div class="label">آماده شروع</div>
          </div>
        </div>
        <div class="timer-controls">
          <button class="btn btn-primary btn-lg" id="studyTimerStart">شروع</button>
          <button class="btn btn-secondary" id="studyTimerReset">بازنشانی</button>
        </div>
        <button class="btn btn-ghost mt-1" id="enterFocusMode">حالت تمرکز</button>
        <div class="mt-2 text-muted" style="font-size:0.85rem;text-align:center">
          امروز: ${formatDuration(Math.round(state.studySessions.filter(s => s.date === new Date().toISOString().slice(0,10)).reduce((a,b)=>a+b.actualMin,0)))}
        </div>
      </div>
    `;
  }

  function renderNotesView() {
    return `
      <div class="section-title">
        <span>یادداشت‌ها</span>
        <button class="btn btn-primary btn-sm" id="addNoteBtn">+ یادداشت</button>
      </div>
      <div class="notes-grid">
        ${state.notes.length ? state.notes.map(n => `
          <div class="note-card ${n.pinned ? 'pinned' : ''}" data-note-id="${n.id}">
            <div class="note-title">${n.title || 'بدون عنوان'}</div>
            <div class="note-preview">${n.content || ''}</div>
            <div class="note-footer">
              <span>${n.subject || ''}</span>
              <span>${n.pinned ? '📌' : ''}</span>
            </div>
          </div>
        `).join('') : `
          <div class="empty-state" style="grid-column:1/-1">
            <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            <h3>یادداشتی نیست</h3>
            <p>نکات مهم درسی و ایده‌هایت را اینجا ذخیره کن</p>
          </div>
        `}
      </div>
    `;
  }

  function renderStatisticsView() {
    const today = new Date().toISOString().slice(0, 10);
    const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10);
    const studyToday = state.studySessions.filter(s => s.date === today).reduce((a, b) => a + b.actualMin, 0);
    const studyWeek = state.studySessions.filter(s => s.date >= weekAgo).reduce((a, b) => a + b.actualMin, 0);
    const completedTasks = state.tasks.filter(t => t.status === 'completed').length;
    const totalTasks = state.tasks.length || 1;
    const rate = Math.round((completedTasks / totalTasks) * 100);

    // Simple bar chart data (last 7 days)
    const bars = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      const mins = state.studySessions.filter(s => s.date === d).reduce((a, b) => a + b.actualMin, 0);
      bars.push(mins);
    }
    const maxBar = Math.max(...bars, 1);

    // Insights
    const subjectTimes = {};
    state.studySessions.forEach(s => {
      if (s.subject) subjectTimes[s.subject] = (subjectTimes[s.subject] || 0) + s.actualMin;
    });
    const topSubject = Object.entries(subjectTimes).sort((a, b) => b[1] - a[1])[0];
    const pendingDeadlines = state.tasks.filter(t => t.status !== 'completed' && t.date && t.date <= today).length;

    return `
      <div class="section-title"><span>آمار و تحلیل</span></div>
      <div class="stats-grid">
        <div class="stat-card">
          <span class="stat-label">مطالعه امروز</span>
          <span class="stat-value accent">${formatDuration(Math.round(studyToday))}</span>
        </div>
        <div class="stat-card">
          <span class="stat-label">این هفته</span>
          <span class="stat-value">${formatDuration(Math.round(studyWeek))}</span>
        </div>
        <div class="stat-card">
          <span class="stat-label">تسک‌های کامل</span>
          <span class="stat-value success">${completedTasks}</span>
        </div>
        <div class="stat-card">
          <span class="stat-label">نرخ تکمیل</span>
          <span class="stat-value">${rate}٪</span>
        </div>
      </div>
      <div class="chart-card mb-2">
        <div class="section-title" style="margin-bottom:0.5rem"><span>عملکرد هفتگی (دقیقه مطالعه)</span></div>
        <div class="chart-placeholder">
          ${bars.map(m => `<div class="bar" style="height:${Math.max(8, (m / maxBar) * 160)}px" title="${Math.round(m)}د"></div>`).join('')}
        </div>
      </div>
      <div class="section-title"><span>بینش‌های هوشمند</span></div>
      <div class="insights">
        ${topSubject ? `<div class="insight-item">این هفته بیشتر زمان مطالعه‌ات صرف «${topSubject[0]}» شده (${formatDuration(Math.round(topSubject[1]))}).</div>` : ''}
        ${pendingDeadlines > 0 ? `<div class="insight-item">${pendingDeadlines} تسک تا موعد مقرر باقی مانده یا گذشته است.</div>` : '<div class="insight-item">همه تسک‌های دارای موعد به‌روز هستند.</div>'}
        ${studyWeek > 0 ? `<div class="insight-item">مجموع مطالعه این هفته: ${formatDuration(Math.round(studyWeek))}.</div>` : '<div class="insight-item">هنوز جلسه‌ای ثبت نشده. اولین تایمر را شروع کن!</div>'}
      </div>
    `;
  }

  function renderSettingsView() {
    const themes = [
      { id: 'neon', name: 'نئون سبز', color: '#39ff78' },
      { id: 'gold', name: 'طلایی', color: '#c9a227' },
      { id: 'dark', name: 'تاریک طلایی', color: '#d4af37' },
      { id: 'light', name: 'روشن', color: '#b45309' },
      { id: 'midnight', name: 'نیمه‌شب', color: '#818cf8' },
      { id: 'ocean', name: 'اقیانوس', color: '#22d3ee' },
      { id: 'rose', name: 'رز', color: '#fb7185' },
      { id: 'system', name: 'سیستم', color: '#94a3b8' }
    ];
    return `
      <div class="section-title"><span>تنظیمات</span></div>
      <div class="card">
        <div class="settings-section">
          <h3>ظاهر</h3>
          <div class="settings-item" style="flex-direction:column;align-items:stretch;gap:0.75rem">
            <div>
              <div class="settings-label">تم رنگی</div>
              <div class="settings-desc">یکی از تم‌های زیبا را انتخاب کن</div>
            </div>
            <div class="theme-grid">
              ${themes.map(t => `
                <button class="theme-card ${state.settings.theme === t.id ? 'active' : ''}" data-theme="${t.id}">
                  <span class="theme-dot" style="background:${t.color}"></span>
                  <span>${t.name}</span>
                </button>
              `).join('')}
            </div>
          </div>
        </div>
        <div class="settings-section">
          <h3>تقویم و زمان</h3>
          <div class="settings-item">
            <div>
              <div class="settings-label">نوع تقویم</div>
            </div>
            <select class="form-select" id="setCalType" style="width:auto">
              <option value="jalali" ${state.settings.calendarType === 'jalali' ? 'selected' : ''}>شمسی</option>
              <option value="gregorian" ${state.settings.calendarType === 'gregorian' ? 'selected' : ''}>میلادی</option>
            </select>
          </div>
        </div>
        <div class="settings-section">
          <h3>اعلان‌ها و صدا</h3>
          <div class="settings-item">
            <div>
              <div class="settings-label">صدای پایان تایمر</div>
            </div>
            <div class="toggle ${state.settings.soundEnabled ? 'on' : ''}" id="soundToggle"></div>
          </div>
          <div class="settings-item">
            <div>
              <div class="settings-label">اعلان‌ها</div>
            </div>
            <div class="toggle ${state.settings.notifications ? 'on' : ''}" id="notifToggle"></div>
          </div>
        </div>
        <div class="settings-section">
          <h3>هوش مصنوعی آنلاین</h3>
          <div class="settings-item">
            <div>
              <div class="settings-label">ارائه‌دهنده</div>
              <div class="settings-desc">Groq رایگان · OpenAI · OpenRouter</div>
            </div>
            <select class="form-select" id="setAiProvider" style="width:auto">
              <option value="groq" ${state.settings.aiProvider === 'groq' ? 'selected' : ''}>Groq</option>
              <option value="openai" ${state.settings.aiProvider === 'openai' ? 'selected' : ''}>OpenAI</option>
              <option value="openrouter" ${state.settings.aiProvider === 'openrouter' ? 'selected' : ''}>OpenRouter</option>
            </select>
          </div>
          <div class="settings-item" style="flex-direction:column;align-items:stretch;gap:0.5rem">
            <div class="settings-label">کلید API</div>
            <input type="password" class="form-input" id="setAiKey" value="${state.settings.aiApiKey || ''}" placeholder="sk-... یا gsk_..." />
          </div>
          <div class="settings-item" style="flex-direction:column;align-items:stretch;gap:0.5rem">
            <div class="settings-label">مدل</div>
            <input class="form-input" id="setAiModel" value="${state.settings.aiModel || 'llama-3.3-70b-versatile'}" placeholder="llama-3.3-70b-versatile" />
          </div>
          <div class="settings-item" style="flex-direction:column;align-items:stretch;gap:0.5rem">
            <div>
              <div class="settings-label">آدرس پایه سفارشی (اختیاری)</div>
              <div class="settings-desc">اگر خالی باشد از آدرس پیش‌فرض ارائه‌دهنده استفاده می‌شود</div>
            </div>
            <input class="form-input" id="setAiBase" value="${state.settings.aiBaseUrl || ''}" placeholder="https://api.groq.com/openai/v1" />
          </div>
          <p class="text-muted" style="font-size:0.8rem;margin:0.5rem 0 0">کلید فقط روی دستگاه خودت در LocalStorage ذخیره می‌شود و به سرور ما ارسال نمی‌شود.</p>
        </div>
        <div class="settings-section">
          <h3>برنامه‌ریزی پیشرفته</h3>
          <div class="settings-item">
            <div>
              <div class="settings-label">هدف مطالعه روزانه (دقیقه)</div>
              <div class="settings-desc">برای پیشنهاد هوشمند و برنامه‌ریز هفته</div>
            </div>
            <input type="number" class="form-input" id="setDailyGoal" value="${state.dailyStudyGoalMin || 90}" min="15" max="600" style="width:100px" />
          </div>
          <div class="settings-item">
            <div>
              <div class="settings-label">اعلان مرورگر</div>
              <div class="settings-desc">یادآوری پایان تایمر و هشدارها</div>
            </div>
            <button class="btn btn-secondary btn-sm" id="enableNotifyBtn">فعال‌سازی</button>
          </div>
        </div>
        <div class="settings-section">
          <h3>پشتیبان‌گیری</h3>
          <div class="settings-item">
            <div>
              <div class="settings-label">خروجی JSON</div>
              <div class="settings-desc">دانلود تمام داده‌ها</div>
            </div>
            <button class="btn btn-secondary btn-sm" id="exportDataBtn">دانلود</button>
          </div>
          <div class="settings-item">
            <div>
              <div class="settings-label">ورود از فایل</div>
              <div class="settings-desc">بازیابی پشتیبان</div>
            </div>
            <label class="btn btn-secondary btn-sm" style="cursor:pointer">انتخاب فایل
              <input type="file" id="importDataFile" accept="application/json,.json" hidden />
            </label>
          </div>
        </div>
        <div class="settings-section">
          <h3>حساب</h3>
          <div class="settings-item">
            <div>
              <div class="settings-label">نام نمایشی</div>
            </div>
            <input class="form-input" id="setUserName" value="${state.user.name || ''}" style="width:160px" />
          </div>
          <div class="settings-item">
            <button class="btn btn-secondary btn-sm" id="resetDataBtn">بازنشانی داده‌ها</button>
          </div>
        </div>
      </div>
    `;
  }

  // -------------------- Navigation & Render --------------------



  function buildStudyContext() {
    const today = new Date().toISOString().slice(0, 10);
    const pending = state.tasks.filter(t => t.status !== 'completed');
    const upcoming = state.exams.filter(e => e.date && e.date >= today).sort((a, b) => a.date.localeCompare(b.date));
    const subjects = state.subjects.map(s => s.name).join('، ') || '—';
    if (typeof ensureSchoolShape === 'function') ensureSchoolShape();
    return {
      name: state.user.name || 'دانش‌آموز',
      subjects,
      pendingTasks: pending.slice(0, 12).map(t => `${t.title}${t.subject ? ' (' + t.subject + ')' : ''}${t.priority === 'high' ? ' [فوری]' : ''}`),
      exams: upcoming.slice(0, 6).map(e => `${e.name} — ${e.date}${e.time ? ' ' + e.time : ''}`),
      school: `${state.school.startTime} تا ${state.school.endTime}`,
      periods: (state.school.periodSlots || []).map((p, i) => `زنگ${i + 1}: ${p.start}-${p.end}`).join(' | '),
      goals: state.goals.slice(0, 5).map(g => g.title)
    };
  }

  function dayNameToIndex(name) {
    const map = {
      'یکشنبه': 0, 'يكشنبه': 0, 'دوشنبه': 1, 'سه‌شنبه': 2, 'سه شنبه': 2, 'سهشنبه': 2,
      'چهارشنبه': 3, 'پنج‌شنبه': 4, 'پنجشنبه': 4, 'جمعه': 5, 'شنبه': 6
    };
    for (const k of Object.keys(map)) {
      if (name.includes(k)) return map[k];
    }
    return null;
  }

  function findSubjectByText(text) {
    const t = (text || '').trim();
    let s = state.subjects.find(x => t.includes(x.name));
    if (s) return s;
    const aliases = [
      ['ریاضی', 'ریاضی'], ['رياضی', 'ریاضی'], ['فیزیک', 'فیزیک'], ['فيزیک', 'فیزیک'],
      ['شیمی', 'شیمی'], ['شيمي', 'شیمی'], ['زیست', 'زیست'], ['زيست', 'زیست'],
      ['انگلیسی', 'انگلیسی'], ['انگليسی', 'انگلیسی'], ['زبان', 'انگلیسی']
    ];
    for (const [a, n] of aliases) {
      if (t.includes(a)) {
        s = state.subjects.find(x => x.name === n || x.name.includes(n));
        if (s) return s;
      }
    }
    return null;
  }

  function runLocalAgent(q) {
    const raw = q.trim();
    const actions = [];
    const today = new Date().toISOString().slice(0, 10);

    let m = raw.match(/(?:درس(?:\s+جدید)?)\s+([^\s،,]+(?:\s+[^\s،,]+)?)\s*(?:اضافه|بساز|ثبت)/i);
    if (!m) m = raw.match(/(?:اضافه|بساز|ثبت)\s*(?:کن\s+)?درس\s+([^\s،,]+)/i);
    if (m) {
      const name = m[1].trim();
      if (!state.subjects.some(s => s.name === name)) {
        const colorKeys = ['math','physics','chem','bio','english','history','default'];
        state.subjects.push({ id: uid(), name, color: colorKeys[state.subjects.length % colorKeys.length] });
        actions.push('درس «' + name + '» اضافه شد');
      } else actions.push('درس «' + name + '» از قبل وجود داشت');
    }

    const wantsTask = /تسک|کار|مطالعه|مرور/.test(raw) && /اضافه|بساز|ثبت/.test(raw);
    if (wantsTask) {
      let title = raw
        .replace(/^(?:لطفاً?\s*)?/, '')
        .replace(/تسک\s*/, '')
        .replace(/کار\s*/, '')
        .replace(/(?:را\s*)?(?:اضافه|بساز|ثبت)\s*کن?/, '')
        .trim();
      const minsMatch = raw.match(/(\d+)\s*دقیقه/);
      const mins = minsMatch ? parseInt(minsMatch[1], 10) : 30;
      title = title.replace(/\d+\s*دقیقه/, '').trim();
      if (title.length > 2) {
        const subj = findSubjectByText(raw);
        state.tasks.push({
          id: uid(),
          title: title,
          subject: subj ? subj.name : '',
          duration: mins,
          priority: /فوری|مهم|اولویت/.test(raw) ? 'high' : 'medium',
          status: 'pending',
          date: today,
          notes: '',
          createdAt: Date.now()
        });
        actions.push('تسک «' + title + '» (' + mins + ' دقیقه) اضافه شد');
      }
    }

    if (/امتحان/.test(raw) && /اضافه|بساز|ثبت/.test(raw)) {
      const dateMatch = raw.match(/(\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2})/);
      const date = dateMatch ? dateMatch[1].replace(/\//g, '-') : today;
      let name = raw.replace(/امتحان\s*/, '').replace(/(?:را\s*)?(?:اضافه|بساز|ثبت)\s*کن?/, '').replace(/\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}/, '').replace(/روز\s*/, '').trim();
      if (!name) name = 'امتحان';
      const subj = findSubjectByText(raw);
      state.exams.push({ id: uid(), name: name, subject: subj ? subj.name : '', date: date, time: '', notes: '' });
      actions.push('امتحان «' + name + '» برای ' + date + ' ثبت شد');
    }

    const dayMatch = raw.match(/(شنبه|یکشنبه|دوشنبه|سه‌شنبه|سه شنبه|چهارشنبه|پنج‌شنبه|پنجشنبه|جمعه)/);
    const periodMatch = raw.match(/زنگ\s*(اول|دوم|سوم|چهارم|پنجم|ششم|۱|1|۲|2|۳|3|۴|4|۵|5|۶|6)/);
    if (dayMatch && (periodMatch || findSubjectByText(raw))) {
      const day = dayNameToIndex(dayMatch[1]);
      const periodMap = { 'اول': 0, '۱': 0, '1': 0, 'دوم': 1, '۲': 1, '2': 1, 'سوم': 2, '۳': 2, '3': 2, 'چهارم': 3, '۴': 3, '4': 3, 'پنجم': 4, '۵': 4, '5': 4, 'ششم': 5, '۶': 5, '6': 5 };
      let pi = periodMatch ? (periodMap[periodMatch[1]] ?? 0) : 0;
      const subj = findSubjectByText(raw);
      if (day != null && subj) {
        if (typeof ensureSchoolShape === 'function') ensureSchoolShape();
        if (!state.school.days.includes(day)) state.school.days.push(day);
        if (!state.school.timetable) state.school.timetable = {};
        state.school.timetable[day + '_' + pi] = subj.name;
        actions.push('جدول: ' + dayMatch[1] + ' زنگ ' + (pi + 1) + ' → ' + subj.name);
      }
    }

    if (/هدف/.test(raw) && /اضافه|بساز|ثبت/.test(raw)) {
      let title = raw.replace(/هدف\s*/, '').replace(/(?:را\s*)?(?:اضافه|بساز|ثبت)\s*کن?/, '').trim();
      if (title) {
        state.goals.push({ id: uid(), title: title, progress: 0, target: 100 });
        actions.push('هدف «' + title + '» اضافه شد');
      }
    }

    if (actions.length) {
      saveState();
      return 'انجام شد:\n• ' + actions.join('\n• ') + '\n\nاز منوی مربوطه می‌توانی نتیجه را ببینی.';
    }
    return null;
  }

  function localAIFallback(q) {
    const agent = runLocalAgent(q);
    if (agent) return agent;
    const ctx = buildStudyContext();
    const pending = state.tasks.filter(t => t.status !== 'completed');
    const high = pending.filter(t => t.priority === 'high');
    const upcoming = state.exams.filter(e => e.date && e.date >= new Date().toISOString().slice(0, 10)).sort((a, b) => a.date.localeCompare(b.date));
    if (/امروز|اول|برنامه/.test(q)) {
      if (high.length) return 'اولویت امروز:\n• ' + high.slice(0, 5).map(t => t.title).join('\n• ');
      if (pending.length) return 'تسک‌های باز:\n• ' + pending.slice(0, 6).map(t => t.title).join('\n• ');
      return 'تسک بازی نداری. بگو: «تسک مطالعه فصل ۳ فیزیک ۴۰ دقیقه اضافه کن»';
    }
    if (/امتحان/.test(q)) {
      if (upcoming[0]) return 'نزدیک‌ترین امتحان: «' + upcoming[0].name + '» در ' + upcoming[0].date;
      return 'امتحانی نیست. بگو: «امتحان ریاضی روز 2026-10-20 اضافه کن»';
    }
    return 'وضعیت: ' + pending.length + ' تسک باز · ' + upcoming.length + ' امتحان · درس‌ها: ' + ctx.subjects + '\n\nدستور نمونه:\n• تسک مرور ریاضی ۲۵ دقیقه اضافه کن\n• درس زیست اضافه کن\n• شنبه زنگ اول ریاضی\n• امتحان فیزیک روز 2026-11-01 اضافه کن';
  }

  function extractAIText(resp) {
    if (resp == null) return '';
    if (typeof resp === 'string') return resp.trim();
    if (typeof resp === 'object') {
      if (typeof resp.message === 'string') return resp.message.trim();
      if (resp.message && typeof resp.message.content === 'string') return resp.message.content.trim();
      if (typeof resp.content === 'string') return resp.content.trim();
      if (typeof resp.text === 'string') return resp.text.trim();
      if (Array.isArray(resp)) return resp.map(extractAIText).filter(Boolean).join('\n').trim();
    }
    try { return String(resp); } catch (e) { return ''; }
  }

  async function aiRespondViaPuter(question) {
    if (typeof puter === 'undefined' || !puter.ai || !puter.ai.chat) throw new Error('Puter در دسترس نیست');
    const ctx = buildStudyContext();
    const prompt = 'تو دستیار تحصیلی فارسی هستی. کوتاه جواب بده.\nدرس‌ها: ' + ctx.subjects + '\nتسک‌ها: ' + (ctx.pendingTasks.join(' | ') || 'هیچ') + '\nسؤال: ' + question;
    const resp = await puter.ai.chat(prompt);
    const text = extractAIText(resp);
    if (!text) throw new Error('پاسخ خالی Puter');
    return text;
  }

  async function aiRespondViaPollinations(question) {
    const ctx = buildStudyContext();
    const res = await fetch('https://text.pollinations.ai/openai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Referer': 'https://oriz.in' },
      body: JSON.stringify({
        model: 'openai',
        messages: [
          { role: 'system', content: 'دستیار تحصیلی فارسی. کوتاه جواب بده. درس‌ها: ' + ctx.subjects },
          { role: 'user', content: question }
        ]
      })
    });
    if (!res.ok) throw new Error('Pollinations ' + res.status);
    const data = await res.json();
    const text = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    if (!text) throw new Error('پاسخ خالی');
    return String(text).trim();
  }

  async function aiRespondViaApiKey(question) {
    const key = (state.settings.aiApiKey || '').trim();
    if (!key) throw new Error('کلید نیست');
    const p = state.settings.aiProvider || 'groq';
    const custom = (state.settings.aiBaseUrl || '').trim();
    let url = custom ? custom.replace(/\/$/, '') + '/chat/completions' : (p === 'openai' ? 'https://api.openai.com/v1/chat/completions' : p === 'openrouter' ? 'https://openrouter.ai/api/v1/chat/completions' : 'https://api.groq.com/openai/v1/chat/completions');
    const model = state.settings.aiModel || 'llama-3.3-70b-versatile';
    const headers = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key };
    const res = await fetch(url, { method: 'POST', headers, body: JSON.stringify({ model: model, messages: [{ role: 'user', content: question }], max_tokens: 700 }) });
    if (!res.ok) throw new Error('API ' + res.status);
    const data = await res.json();
    const text = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    if (!text) throw new Error('خالی');
    return String(text).trim();
  }

  async function aiRespondOnline(question) {
    try { return await aiRespondViaPuter(question); } catch (e1) { console.warn(e1); }
    try { return await aiRespondViaPollinations(question); } catch (e2) { console.warn(e2); }
    if ((state.settings.aiApiKey || '').trim()) {
      try { return await aiRespondViaApiKey(question); } catch (e3) { console.warn(e3); }
    }
    throw new Error('آنلاین در دسترس نیست');
  }

  function renderAIView() {
    return `
      <div class="section-title"><span>دستیار هوشمند</span></div>
      <div class="card mb-2" style="border-color:var(--accent);box-shadow:0 0 24px var(--accent-soft)">
        <p style="margin:0 0 0.5rem;color:var(--text-secondary);font-size:0.9rem">
          برنامه‌ات را بگو تا <b>خودش در سایت ثبت کند</b>. نمونه‌ها را بزن یا خودت بنویس.
        </p>
        <div class="ai-suggestions" style="display:flex;flex-wrap:wrap;gap:0.5rem;margin-bottom:1rem">
          <button class="btn btn-secondary btn-sm ai-sug" data-q="تسک مطالعه فصل ۳ فیزیک ۴۰ دقیقه اضافه کن">افزودن تسک</button>
          <button class="btn btn-secondary btn-sm ai-sug" data-q="شنبه زنگ اول ریاضی">زنگ در جدول</button>
          <button class="btn btn-secondary btn-sm ai-sug" data-q="درس زیست اضافه کن">درس جدید</button>
          <button class="btn btn-secondary btn-sm ai-sug" data-q="امروز چه کارهایی را اول انجام بدهم؟">برنامه امروز</button>
          <button class="btn btn-secondary btn-sm ai-sug" data-q="امتحان شیمی روز 2026-11-15 اضافه کن">امتحان</button>
        </div>
        <div id="aiChat" class="ai-chat" style="min-height:200px;max-height:360px;overflow-y:auto;display:flex;flex-direction:column;gap:0.65rem;margin-bottom:1rem">
          <div class="ai-bubble ai-bot">سلام! بگو چه چیزی اضافه کنم. مثلاً «تسک مرور ریاضی ۲۵ دقیقه اضافه کن» یا «شنبه زنگ دوم فیزیک».</div>
        </div>
        <div style="display:flex;gap:0.5rem">
          <input class="form-input" id="aiInput" placeholder="دستور یا سؤال..." style="flex:1" />
          <button class="btn btn-primary" id="aiSend">ارسال</button>
        </div>
      </div>
    `;
  }

  async function aiRespond(question) {
    const q = (question || '').trim();
    if (!q) return;
    const chat = document.getElementById('aiChat');
    if (!chat) return;
    const user = document.createElement('div');
    user.className = 'ai-bubble ai-user';
    user.textContent = q;
    chat.appendChild(user);
    const loading = document.createElement('div');
    loading.className = 'ai-bubble ai-bot';
    loading.textContent = 'در حال انجام...';
    chat.appendChild(loading);
    chat.scrollTop = chat.scrollHeight;

    let answer = runLocalAgent(q);
    if (!answer) {
      try { answer = await aiRespondOnline(q); }
      catch (err) { console.warn(err); answer = localAIFallback(q); }
    }
    loading.remove();
    const bot = document.createElement('div');
    bot.className = 'ai-bubble ai-bot';
    bot.style.whiteSpace = 'pre-wrap';
    bot.textContent = answer;
    chat.appendChild(bot);
    chat.scrollTop = chat.scrollHeight;
  }




  function renderPlannerView() {
    ensureSchoolShape();
    const dayLabels = ['یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنج‌شنبه','جمعه','شنبه'];
    const today = new Date();
    // week starting Saturday
    const satOffset = (today.getDay() + 1) % 7; // 0 if Saturday
    const start = new Date(today);
    start.setDate(today.getDate() - satOffset);
    const days = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      const key = d.toISOString().slice(0, 10);
      const jsDay = d.getDay(); // 0 Sun
      days.push({
        key, jsDay, label: dayLabels[jsDay],
        tasks: state.tasks.filter(t => t.date === key && t.status !== 'completed'),
        exams: state.exams.filter(e => e.date === key),
        studyMin: getStudyMinutesOn(key)
      });
    }
    const goal = state.dailyStudyGoalMin || 90;
    return `
      <div class="section-title">
        <span>برنامه‌ریز هفتگی</span>
        <button class="btn btn-secondary btn-sm" id="setDailyGoalBtn">هدف روزانه: ${goal}د</button>
      </div>
      <p class="text-muted" style="font-size:0.85rem;margin-bottom:1rem">نمای هفته از شنبه — تسک‌ها، امتحان‌ها و دقیقه مطالعه هر روز.</p>
      <div class="planner-grid">
        ${days.map(day => `
          <div class="card planner-day ${day.key === today.toISOString().slice(0,10) ? 'planner-today' : ''}">
            <div class="flex-between mb-1">
              <strong>${day.label}</strong>
              <span class="text-muted" style="font-size:0.75rem">${day.key.slice(5)}</span>
            </div>
            <div class="text-muted" style="font-size:0.8rem;margin-bottom:0.5rem">مطالعه: ${Math.round(day.studyMin)}د / ${goal}د</div>
            <div class="mini-progress"><div class="mini-progress-bar" style="width:${Math.min(100, (day.studyMin/goal)*100)}%"></div></div>
            ${day.exams.map(e => `<div class="planner-chip exam">امتحان: ${e.name}</div>`).join('')}
            ${day.tasks.slice(0,4).map(t => `<div class="planner-chip">${t.title}</div>`).join('') || '<div class="text-muted" style="font-size:0.8rem">تسکی نیست</div>'}
            ${day.tasks.length > 4 ? `<div class="text-muted" style="font-size:0.75rem">+${day.tasks.length-4} مورد</div>` : ''}
          </div>
        `).join('')}
      </div>
    `;
  }

  function renderGradesView() {
    if (!state.grades) state.grades = [];
        if (!state.activityLog) state.activityLog = [];
        if (!state.generatedPlans) state.generatedPlans = [];
    const bySubj = {};
    state.grades.forEach(g => {
      if (!bySubj[g.subject]) bySubj[g.subject] = [];
      bySubj[g.subject].push(g);
    });
    const avg = state.grades.length
      ? (state.grades.reduce((a, g) => a + Number(g.score), 0) / state.grades.length).toFixed(1)
      : '—';
    return `
      <div class="section-title">
        <span>نمرات</span>
        <button class="btn btn-primary btn-sm" id="addGradeBtn">+ نمره</button>
      </div>
      <div class="overview-row">
        <div class="stat-card"><span class="stat-label">میانگین</span><span class="stat-value accent">${avg}</span></div>
        <div class="stat-card"><span class="stat-label">تعداد ثبت</span><span class="stat-value">${state.grades.length}</span></div>
      </div>
      <div class="card">
        ${state.grades.length ? `
          <div class="grade-list">
            ${state.grades.slice().reverse().map(g => `
              <div class="grade-row" data-id="${g.id}">
                <div>
                  <strong>${g.title || 'نمره'}</strong>
                  <div class="text-muted" style="font-size:0.8rem">${g.subject || '—'} · ${g.date || ''}</div>
                </div>
                <div style="display:flex;align-items:center;gap:0.5rem">
                  <span class="stat-value" style="font-size:1.1rem">${g.score}</span>
                  <button class="btn btn-danger btn-sm del-grade" data-id="${g.id}">حذف</button>
                </div>
              </div>
            `).join('')}
          </div>
        ` : '<div class="empty-state"><h3>نمره‌ای ثبت نشده</h3><p>نمرات آزمون و کلاسی را اینجا پیگیری کن</p></div>'}
      </div>
    `;
  }

  function openGradeModal() {
    const subjOpts = state.subjects.map(s => `<option value="${s.name}">${s.name}</option>`).join('');
    openModal(`
      <div class="modal-header"><h2 class="modal-title">ثبت نمره</h2><button class="btn-icon" onclick="closeModal()">✕</button></div>
      <div class="modal-body">
        <div class="form-group"><label class="form-label">عنوان</label><input class="form-input" id="gradeTitle" placeholder="آزمون میان‌ترم" /></div>
        <div class="form-group"><label class="form-label">درس</label><select class="form-select" id="gradeSubject"><option value="">—</option>${subjOpts}</select></div>
        <div class="form-group"><label class="form-label">نمره</label><input type="number" class="form-input" id="gradeScore" min="0" max="20" step="0.25" placeholder="18.5" /></div>
        <div class="form-group"><label class="form-label">تاریخ</label><input type="date" class="form-input" id="gradeDate" value="${new Date().toISOString().slice(0,10)}" /></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="closeModal()">انصراف</button>
        <button class="btn btn-primary" id="saveGradeBtn">ذخیره</button>
      </div>
    `);
    document.getElementById('saveGradeBtn').onclick = () => {
      const score = parseFloat(document.getElementById('gradeScore').value);
      if (isNaN(score)) { toast('نمره را وارد کن'); return; }
      state.grades.push({
        id: uid(),
        title: document.getElementById('gradeTitle').value.trim() || 'نمره',
        subject: document.getElementById('gradeSubject').value,
        score,
        date: document.getElementById('gradeDate').value
      });
      saveState();
      closeModal();
      renderCurrentView();
      toast('نمره ثبت شد');
    };
  }


  const views = {
    dashboard: renderDashboard,
    tasks: renderTasksView,
    calendar: renderCalendarView,
    school: renderSchoolView,
    exams: renderExamsView,
    subjects: renderSubjectsView,
    goals: renderGoalsView,
    timer: renderTimerView,
    notes: renderNotesView,
    statistics: renderStatisticsView,
    planner: renderPlannerView,
    grades: renderGradesView,
    activity: renderActivityView,
    planbuilder: renderPlanBuilderView,
    settings: renderSettingsView,
    ai: renderAIView
  };

  function renderCurrentView() {
    const main = $('#main');
    const fn = views[state.currentView] || views.dashboard;
    main.innerHTML = `<div class="view active">${fn()}</div>`;
    bindViewEvents();
    requestAnimationFrame(() => bind3DTilt());
  }

  function navigateTo(view) {
    state.currentView = view;
    $$('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.view === view));
    closeSidebar();
    renderCurrentView();
    saveState();
  }

  function bindViewEvents() {
    // Task interactions
    $$('[data-action="toggle"]').forEach(el => {
      el.addEventListener('click', e => {
        e.stopPropagation();
        toggleTaskComplete(el.dataset.id);
      });
    });
    $$('[data-action="start-timer"]').forEach(el => {
      el.addEventListener('click', e => {
        e.stopPropagation();
        startTaskTimer(el.dataset.id);
      });
    });
    $$('.task-item').forEach(el => {
      el.addEventListener('dblclick', () => {
        const task = state.tasks.find(t => t.id === el.dataset.taskId);
        if (task) openTaskModal(task);
      });
    });
    $$('.exam-card[data-exam-id]').forEach(el => {
      el.addEventListener('click', () => {
        const exam = state.exams.find(e => e.id === el.dataset.examId);
        if (exam) openExamModal(exam);
      });
    });

    // Dashboard timer controls
    $('#dashPauseTimer')?.addEventListener('click', () => {
      if (state.activeTimer?.isPaused) resumeTimer();
      else pauseTimer();
      renderCurrentView();
    });
    $('#dashFinishTimer')?.addEventListener('click', () => {
      stopTimer(true);
      toast('تسک با موفقیت انجام شد ✓');
    });

    // Settings - Themes
    $$('.theme-card, .theme-opt').forEach(btn => {
      btn.addEventListener('click', () => {
        state.settings.theme = btn.dataset.theme;
        applyTheme();
        saveState();
        renderCurrentView();
      });
    });
    $('#soundToggle')?.addEventListener('click', () => {
      state.settings.soundEnabled = !state.settings.soundEnabled;
      saveState();
      renderCurrentView();
    });
    $('#notifToggle')?.addEventListener('click', () => {
      state.settings.notifications = !state.settings.notifications;
      saveState();
      renderCurrentView();
    });
    $('#setUserName')?.addEventListener('change', e => {
      state.user.name = e.target.value.trim();
      $('#userName').textContent = state.user.name || 'کاربر';
      $('.avatar').textContent = (state.user.name || 'A')[0];
      saveState();
      updateGreeting(new Date());
    });
    $('#resetDataBtn')?.addEventListener('click', () => {
      if (confirm('همه داده‌ها پاک شوند؟ این عمل قابل بازگشت نیست.')) {
        localStorage.removeItem(STORAGE_KEY);
        location.reload();
      }
    });

    // Goals
    $('#addGoalBtn')?.addEventListener('click', () => {
      const title = prompt('عنوان هدف:');
      if (title) {
        state.goals.push({ id: uid(), title, progress: 0, deadline: '' });
        saveState();
        renderCurrentView();
      }
    });

    // Notes
    $('#addNoteBtn')?.addEventListener('click', () => {
      const title = prompt('عنوان یادداشت:');
      if (title !== null) {
        state.notes.unshift({ id: uid(), title: title || 'بدون عنوان', content: '', pinned: false, createdAt: Date.now() });
        saveState();
        renderCurrentView();
      }
    });

    // School edit
    $('#editSchoolHoursBtn')?.addEventListener('click', () => {
      toast('روزهای مدرسه را از دکمه‌های رنگی بالا روشن/خاموش کن. ساعت هر زنگ از «ساعت‌بندی زنگ‌ها» تنظیم می‌شود.');
    });
    $('#editPeriodTimesBtn')?.addEventListener('click', () => openPeriodSlotsModal());
    $$('.school-day-toggle').forEach(btn => {
      btn.addEventListener('click', () => {
        const d = parseInt(btn.dataset.day);
        const idx = state.school.days.indexOf(d);
        if (idx >= 0) state.school.days.splice(idx, 1);
        else state.school.days.push(d);
        state.school.days.sort();
        saveState();
        renderCurrentView();
      });
    });
    $$('.tt-cell').forEach(btn => {
      btn.addEventListener('click', () => {
        if (!state.subjects.length) { toast('اول از بخش دروس، درس اضافه کن'); return; }
        const names = state.subjects.map(s => s.name);
        const cur = state.school.timetable?.[btn.dataset.key] || '';
        const list = ['(خالی)', ...names].join(' | ');
        const pick = prompt('درس این زنگ را بنویس (یا خالی بگذار):\n' + names.join('، '), cur);
        if (pick === null) return;
        if (!state.school.timetable) state.school.timetable = {};
        const val = pick.trim();
        if (!val || val === '—' || val === '(خالی)') delete state.school.timetable[btn.dataset.key];
        else state.school.timetable[btn.dataset.key] = val;
        saveState();
        renderCurrentView();
      });
    });

    // Subjects CRUD
    $('#addSubjectBtn')?.addEventListener('click', () => openSubjectModal());
    $$('.edit-subject-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const s = state.subjects.find(x => x.id === btn.dataset.id);
        if (s) openSubjectModal(s);
      });
    });
    $$('.del-subject-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (!confirm('این درس حذف شود؟')) return;
        state.subjects = state.subjects.filter(x => x.id !== btn.dataset.id);
        saveState();
        renderCurrentView();
        toast('درس حذف شد');
      });
    });

    // AI
    $('#aiSend')?.addEventListener('click', () => {
      const input = $('#aiInput');
      if (input) { aiRespond(input.value); input.value = ''; }
    });
    $('#aiInput')?.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        aiRespond(e.target.value);
        e.target.value = '';
      }
    });
    $$('.ai-sug').forEach(btn => {
      btn.addEventListener('click', () => aiRespond(btn.dataset.q));
    });


    $('#setAiProvider')?.addEventListener('change', e => {
      state.settings.aiProvider = e.target.value;
      saveState();
    });
    $('#setAiKey')?.addEventListener('change', e => {
      state.settings.aiApiKey = e.target.value.trim();
      saveState();
      toast('کلید API ذخیره شد');
    });
    $('#setAiModel')?.addEventListener('change', e => {
      state.settings.aiModel = e.target.value.trim();
      saveState();
    });
    $('#setAiBase')?.addEventListener('change', e => {
      state.settings.aiBaseUrl = e.target.value.trim();
      saveState();
    });


    $$('[data-template]').forEach(btn => {
      btn.addEventListener('click', () => applyStudyTemplate(btn.dataset.template));
    });
    $('#addGradeBtn')?.addEventListener('click', () => openGradeModal());
    $$('.del-grade').forEach(btn => {
      btn.addEventListener('click', () => {
        state.grades = state.grades.filter(g => g.id !== btn.dataset.id);
        saveState();
        renderCurrentView();
      });
    });
    $('#setDailyGoalBtn')?.addEventListener('click', () => {
      const v = prompt('هدف مطالعه روزانه (دقیقه):', state.dailyStudyGoalMin || 90);
      if (v && !isNaN(parseInt(v, 10))) {
        state.dailyStudyGoalMin = parseInt(v, 10);
        saveState();
        renderCurrentView();
      }
    });
    $('#setDailyGoal')?.addEventListener('change', e => {
      state.dailyStudyGoalMin = parseInt(e.target.value, 10) || 90;
      saveState();
      toast('هدف روزانه ذخیره شد');
    });
    $('#enableNotifyBtn')?.addEventListener('click', () => requestNotifyPermission());
    $('#exportDataBtn')?.addEventListener('click', () => exportData());
    $('#importDataFile')?.addEventListener('change', e => {
      const f = e.target.files && e.target.files[0];
      if (f) importData(f);
    });

    $$('[data-gen-plan]').forEach(btn => {
      btn.addEventListener('click', () => {
        const days = parseInt(btn.dataset.genPlan, 10) || 7;
        if (!confirm('برنامه ' + days + ' روزه ساخته شود و به تسک‌ها اضافه شود؟')) return;
        const result = generateSmartPlan(days);
        toast(result.created.length + ' تسک برنامه‌ریزی شد');
        navigateTo('tasks');
      });
    });
    $('#clearActivityBtn')?.addEventListener('click', () => {
      if (!confirm('لیست پیگیری پاک شود؟')) return;
      state.activityLog = [];
      saveState();
      renderCurrentView();
    });

    // Header timer click
    $('#headerTimerIndicator')?.addEventListener('click', () => {
      if (state.activeTimer) {
        navigateTo('tasks');
      }
    });
  }

  // -------------------- Sidebar --------------------
  function openSidebar() {
    $('#sidebar').classList.add('open');
    $('#sidebar').setAttribute('aria-hidden', 'false');
    $('#hamburgerBtn').setAttribute('aria-expanded', 'true');
  }
  function closeSidebar() {
    $('#sidebar').classList.remove('open');
    $('#sidebar').setAttribute('aria-hidden', 'true');
    $('#hamburgerBtn').setAttribute('aria-expanded', 'false');
  }

  // -------------------- FAB --------------------
  function toggleFab() {
    const menu = $('#fabMenu');
    const fab = $('#fabBtn');
    menu.classList.toggle('hidden');
    fab.classList.toggle('open');
  }

  // -------------------- Onboarding --------------------
  function showOnboarding() {
    const steps = [
      {
        title: 'خوش آمدی به Personal Study OS',
        desc: 'سیستم‌عامل شخصی برای مدیریت کامل زندگی تحصیلی‌ات. بیایید با چند سؤال ساده شروع کنیم.',
        fields: `<div class="form-group"><label class="form-label">نامت چیست؟</label><input class="form-input" id="obName" placeholder="مثلاً امیرعباس" /></div>`
      },
      {
        title: 'روزهای مدرسه',
        desc: 'کدام روزها به مدرسه می‌روی؟',
        fields: `<div style="display:flex;flex-wrap:wrap;gap:0.5rem" id="obDays">
          ${['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنج‌شنبه','جمعه'].map((d,i) => {
            const dayIdx = (i + 6) % 7; // map to JS day
            const checked = [6,0,1,2,3].includes(dayIdx);
            return `<label style="padding:0.5rem 0.85rem;border:1px solid var(--border);border-radius:var(--radius);cursor:pointer;${checked?'background:var(--accent-soft);border-color:var(--accent)':''}">
              <input type="checkbox" value="${dayIdx}" ${checked?'checked':''} style="display:none" /> ${d}
            </label>`;
          }).join('')}
        </div>`
      },
      {
        title: 'ساعت مدرسه',
        desc: 'معمولاً مدرسه از چه ساعتی شروع و تمام می‌شود؟',
        fields: `
          <div class="form-row">
            <div class="form-group"><label class="form-label">شروع</label><input type="time" class="form-input" id="obStart" value="08:00" /></div>
            <div class="form-group"><label class="form-label">پایان</label><input type="time" class="form-input" id="obEnd" value="14:00" /></div>
          </div>`
      },
      {
        title: 'آماده‌ای!',
        desc: 'داشبورد شخصی‌ات آماده است. هر زمان خواستی می‌توانی تنظیمات را تغییر دهی.',
        fields: `<p style="text-align:center;color:var(--text-secondary)">می‌توانی الان شروع کنی یا بعداً درس‌ها و امتحانات را اضافه کنی.</p>`
      }
    ];

    let step = 0;
    const container = $('#onboarding');
    container.classList.remove('hidden');

    function renderStep() {
      const s = steps[step];
      $('#onboardingSteps').innerHTML = `
        <div class="step-indicator">
          ${steps.map((_, i) => `<div class="step-dot ${i === step ? 'active' : ''}"></div>`).join('')}
        </div>
        <div class="onboarding-step active">
          <h2>${s.title}</h2>
          <p>${s.desc}</p>
          ${s.fields}
          <div class="onboarding-actions">
            <button class="btn btn-ghost" id="obSkip">رد کردن</button>
            <div style="display:flex;gap:0.5rem">
              ${step > 0 ? `<button class="btn btn-secondary" id="obPrev">قبلی</button>` : ''}
              <button class="btn btn-primary" id="obNext">${step === steps.length - 1 ? 'شروع کن' : 'بعدی'}</button>
            </div>
          </div>
        </div>
      `;

      // Day toggles
      $$('#obDays label').forEach(label => {
        label.addEventListener('click', () => {
          const cb = label.querySelector('input');
          cb.checked = !cb.checked;
          label.style.background = cb.checked ? 'var(--accent-soft)' : '';
          label.style.borderColor = cb.checked ? 'var(--accent)' : 'var(--border)';
        });
      });

      $('#obSkip').onclick = finishOnboarding;
      $('#obPrev')?.addEventListener('click', () => { step--; renderStep(); });
      $('#obNext').onclick = () => {
        if (step === 0) {
          const name = $('#obName')?.value.trim();
          if (name) state.user.name = name;
        }
        if (step === 1) {
          const days = $$('#obDays input:checked').map(c => parseInt(c.value));
          if (days.length) state.school.days = days;
        }
        if (step === 2) {
          state.school.startTime = $('#obStart')?.value || '08:00';
          state.school.endTime = $('#obEnd')?.value || '14:00';
        }
        if (step === steps.length - 1) {
          finishOnboarding();
          return;
        }
        step++;
        renderStep();
      };
    }

    function finishOnboarding() {
      state.user.onboarded = true;
      saveState();
      container.classList.add('hidden');
      $('#userName').textContent = state.user.name || 'کاربر';
      $('.avatar').textContent = (state.user.name || 'A')[0];
      updateGreeting(new Date());
      renderCurrentView();
      toast(`خوش آمدی${state.user.name ? ' ' + state.user.name : ''}!`);
    }

    renderStep();
  }

  // -------------------- Background Interaction --------------------
  function initBackground() {
    const orbs = $$('.orb');
    document.addEventListener('mousemove', e => {
      if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      const x = (e.clientX / window.innerWidth - 0.5) * 20;
      const y = (e.clientY / window.innerHeight - 0.5) * 20;
      orbs.forEach((orb, i) => {
        const factor = (i + 1) * 0.3;
        orb.style.transform = `translate(${x * factor}px, ${y * factor}px)`;
      });
    });
  }

  // -------------------- Init --------------------
  
  // Pause heavy animations when tab not visible (speed + battery)
  document.addEventListener('visibilitychange', () => {
    document.body.classList.toggle('perf-pause', document.hidden);
  });

  function init() {
    loadState();
    applyTheme();
    updateClock();
    clockInterval = setInterval(updateClock, 1000);
    updateNotifBadge();
    initBackground();

    // Restore timer loop if needed
    if (state.activeTimer && !state.activeTimer.isPaused) {
      startTimerLoop();
    }

    // Events
    $('#hamburgerBtn').addEventListener('click', openSidebar);
    $('#closeSidebar').addEventListener('click', closeSidebar);
    $('#sidebarOverlay').addEventListener('click', closeSidebar);
    $$('.nav-item').forEach(item => {
      item.addEventListener('click', e => {
        e.preventDefault();
        navigateTo(item.dataset.view);
      });
    });

    $('#fabBtn').addEventListener('click', toggleFab);
    $$('.fab-item').forEach(item => {
      item.addEventListener('click', () => {
        toggleFab();
        const action = item.dataset.action;
        if (action === 'task') openTaskModal();
        else if (action === 'exam') openExamModal();
        else if (action === 'note') {
          navigateTo('notes');
          setTimeout(() => $('#addNoteBtn')?.click(), 100);
        } else if (action === 'study') navigateTo('timer');
        else if (action === 'event') openExamModal(); // reuse for simplicity
      });
    });

    $('#notifBtn').addEventListener('click', () => {
      const panel = $('#notifPanel');
      panel.classList.toggle('hidden');
      if (!panel.classList.contains('hidden')) {
        state.notifications.forEach(n => n.read = true);
        updateNotifBadge();
        renderNotifs();
        saveState();
      }
    });
    $('#clearNotifs')?.addEventListener('click', () => {
      state.notifications = [];
      saveState();
      renderNotifs();
      updateNotifBadge();
    });

    // Close modals on overlay click
    $('#modalOverlay').addEventListener('click', e => {
      if (e.target === $('#modalOverlay')) closeModal();
    });

    // Keyboard
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        closeModal();
        closeSidebar();
        $('#fabMenu').classList.add('hidden');
        $('#fabBtn').classList.remove('open');
        $('#notifPanel').classList.add('hidden');
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        openTaskModal();
      }
    });

    // User info
    $('#userName').textContent = state.user.name || 'کاربر';
    $('.avatar').textContent = (state.user.name || 'A')[0];

    // First load
    if (!state.user.onboarded) {
      showOnboarding();
    } else {
      renderCurrentView();
    }

    // Expose some functions globally for inline handlers
    window.openTaskModal = openTaskModal;
    window.openExamModal = openExamModal;
    window.openSubjectModal = openSubjectModal;
    window.closeModal = closeModal;
  }

  // Start
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
